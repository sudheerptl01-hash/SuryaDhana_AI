'use client'

/**
 * Price alerts (WTCH): "tell me when TCS goes above 2,200 or below 2,050".
 * Levels live on the server (ui-api /api/alerts, data/price_alerts.json). The master controller checks them every
 * minute in market hours and announces a crossing on the Mac (and Telegram when configured), so alerts fire with the
 * terminal closed; while WTCH is open it also triggers a check on every quote refresh. A crossed level fires once
 * and is removed. Not a broker order. Levels saved in this browser by the old version are moved to the server once.
 */
import { useCallback, useEffect, useState } from 'react'
import { getPriceAlerts, putPriceAlert, runPriceAlerts, type AlertHitSrv, type AlertLevelsSrv } from '@/lib/api'

const LEGACY_KEY = 'suryadhana.alerts.v1'
const SEEN_KEY = 'suryadhana.alerts.seen.v2'
export const ALERTS_EVENT = 'suryadhana:alerts'

export type AlertLevels = AlertLevelsSrv
export type AlertHit = AlertHitSrv

function readSeen(): string { try { return localStorage.getItem(SEEN_KEY) || '' } catch { return '' } }
function writeSeen(at: string): void { try { localStorage.setItem(SEEN_KEY, at) } catch { /* private window */ } }

async function migrateLegacy(server: Record<string, AlertLevels>): Promise<boolean> {
  let legacy: Record<string, { above?: number; below?: number }> = {}
  try { legacy = JSON.parse(localStorage.getItem(LEGACY_KEY) || '{}') } catch { return false }
  const todo = Object.entries(legacy).filter(([sym]) => !server[sym])
  for (const [sym, lv] of todo) {
    try { await putPriceAlert(sym, { above: lv.above ?? null, below: lv.below ?? null }) } catch { return false }
  }
  try { localStorage.removeItem(LEGACY_KEY) } catch { /* ignore */ }
  return todo.length > 0
}

export function useAlerts() {
  const [alerts, setAlerts] = useState<Record<string, AlertLevels>>({})
  const [history, setHistory] = useState<AlertHit[]>([])

  const sync = useCallback(async (migrate = false) => {
    try {
      let d = (await getPriceAlerts()).data
      if (migrate && await migrateLegacy(d.alerts)) d = (await getPriceAlerts()).data
      setAlerts(d.alerts); setHistory(d.history)
      if (!readSeen() && d.history[0]) writeSeen(d.history[0].at)     // first visit: old hits are not news
    } catch { /* ui-api down: keep what we have */ }
  }, [])

  useEffect(() => {
    sync(true)
    const on = () => { sync() }
    window.addEventListener(ALERTS_EVENT, on)
    const iv = setInterval(on, 30_000)
    return () => { window.removeEventListener(ALERTS_EVENT, on); clearInterval(iv) }
  }, [sync])

  const setLevel = useCallback(async (sym: string, side: 'above' | 'below', value: number | null, yahoo?: string) => {
    const cur = { ...(alerts[sym] ?? {}) }
    const next = { above: cur.above ?? null, below: cur.below ?? null, [side]: value && value > 0 ? value : null }
    try {
      const d = (await putPriceAlert(sym, { above: next.above, below: next.below, yahoo: yahoo ?? cur.yahoo })).data
      setAlerts(d.alerts); setHistory(d.history)
      window.dispatchEvent(new Event(ALERTS_EVENT))
    } catch { /* surfaced by the next sync */ }
  }, [alerts])

  /** Set (or clear, with nulls) any of the three levels in one call. `move` is an absolute % move vs prev close. */
  const setLevels = useCallback(async (
    sym: string, levels: { above: number | null; below: number | null; move?: number | null }, yahoo?: string,
  ) => {
    try {
      const d = (await putPriceAlert(sym, { ...levels, yahoo: yahoo ?? alerts[sym]?.yahoo })).data
      setAlerts(d.alerts); setHistory(d.history)
      window.dispatchEvent(new Event(ALERTS_EVENT))
    } catch { /* surfaced by the next sync */ }
  }, [alerts])

  /** Set (or clear, with nulls) both price levels in one call. Kept for existing callers (WatchMonitor). */
  const setBoth = useCallback((sym: string, above: number | null, below: number | null, yahoo?: string) =>
    setLevels(sym, { above, below }, yahoo), [setLevels])

  /** Ask the server to check now, then return hits this browser has not shown yet (fired here or by the scheduler). */
  const check = useCallback(async (): Promise<AlertHit[]> => {
    if (Object.keys(alerts).length) { try { await runPriceAlerts() } catch { /* scheduler will catch it */ } }
    let d: { alerts: Record<string, AlertLevels>; history: AlertHit[] }
    try { d = (await getPriceAlerts()).data } catch { return [] }
    setAlerts(d.alerts); setHistory(d.history)
    const seen = readSeen()
    const fresh = d.history.filter(h => h.at > seen)
    if (fresh[0]) writeSeen(fresh[0].at)
    return fresh
  }, [alerts])

  return { alerts, history, setLevel, setLevels, setBoth, check }
}

export function notify(hit: AlertHit): void {
  const text = `${hit.sym} ${hit.side === 'above' ? 'rose above' : 'fell below'} ₹${hit.level.toLocaleString('en-IN')} (now ₹${hit.price.toLocaleString('en-IN')})`
  try {
    if (typeof Notification !== 'undefined' && Notification.permission === 'granted') new Notification('SuryaDhana alert', { body: text })
  } catch { /* notifications unavailable */ }
}
