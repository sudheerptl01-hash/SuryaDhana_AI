'use client'

import { Z } from '@/lib/z'
import { apiError } from '@/lib/errors'
import React, { useEffect, useState, useCallback } from 'react'
import clsx from 'clsx'
import { ThemeProvider, useTheme } from '@/context/ThemeContext'
import { AppProvider, useWatchlist } from '@/context/AppContext'
import {
  getDashboardSummary,
  getEnrichmentStatus,
  listStocks,
  screenStocks,
  triggerRefresh,
  refreshWatchlist,
  getRefreshStatus,
  bootstrapUniverse,
  triggerEnrich,
  getEnrichProgress,
  getDeskStatus,
} from '@/lib/api'
import { getArchiveMeta } from '@/lib/api'
import { goToPage } from '@/lib/navigate'
import { LiveMonitorBar } from '@/components/LiveMonitorBar'
import { MarketCommandHeader } from '@/components/MarketCommandHeader'
import { ToastProvider } from '@/context/ToastContext'
import { ErrorCatcher } from '@/components/ErrorCatcher'
import { NewsDock } from '@/components/news/NewsDock'
import { CommandBar, type CommandPage } from '@/components/CommandBar'
import { Brief } from '@/components/Brief'
import dynamic from 'next/dynamic'

// ── per-tab code splitting (F4.9): BRIEF and the chrome load eagerly; every other tab's chunk
// is fetched when it is first opened, with a TabSkeleton while in flight. ssr:false — the
// terminal is a client app and these pages poll live endpoints on mount.
const lazyTab = (load: () => Promise<React.ComponentType<any>>) =>
  dynamic(load, { loading: () => <TabSkeleton />, ssr: false })
const PipelineStudio = lazyTab(() => import('@/components/PipelineStudio').then(m => m.PipelineStudio))
const LivePortfolio = lazyTab(() => import('@/components/LivePortfolio').then(m => m.LivePortfolio))
const BacktestPanel = lazyTab(() => import('@/components/BacktestPanel').then(m => m.BacktestPanel))
const SystemTelemetry = lazyTab(() => import('@/components/SystemTelemetry').then(m => m.SystemTelemetry))
const LWScanner = lazyTab(() => import('@/components/LWScanner').then(m => m.LWScanner))
const DataExplorerTab = lazyTab(() => import('@/components/DataExplorerTab').then(m => m.DataExplorerTab))
const WarehouseHealth = lazyTab(() => import('@/components/WarehouseHealth').then(m => m.WarehouseHealth))
const AlphaDiscoveryDesk = lazyTab(() => import('@/components/AlphaDiscoveryDesk').then(m => m.AlphaDiscoveryDesk))
const CommodityTab = lazyTab(() => import('@/components/CommodityTab').then(m => m.CommodityTab))
const MLEngineWorkspace = lazyTab(() => import('@/components/MLEngineWorkspace').then(m => m.MLEngineWorkspace))
const GlassBoxStudio = lazyTab(() => import('@/components/GlassBoxStudio').then(m => m.GlassBoxStudio))
const PortfolioSummary = lazyTab(() => import('@/components/PortfolioSummary').then(m => m.PortfolioSummary))
const DecisionDesk = lazyTab(() => import('@/components/DecisionDesk').then(m => m.DecisionDesk))
const MarketMonitor = lazyTab(() => import('@/components/MarketMonitor').then(m => m.MarketMonitor))
const ResearchLibrary = lazyTab(() => import('@/components/ResearchLibrary').then(m => m.ResearchLibrary))
const EventCalendar = lazyTab(() => import('@/components/EventCalendar').then(m => m.EventCalendar))
const WatchMonitor = lazyTab(() => import('@/components/WatchMonitor').then(m => m.WatchMonitor))
const Compare = lazyTab(() => import('@/components/Compare').then(m => m.Compare))
const OptionChain = lazyTab(() => import('@/components/OptionChain').then(m => m.OptionChain))
const InsiderMonitor = lazyTab(() => import('@/components/InsiderMonitor').then(m => m.InsiderMonitor))
const DealsMonitor = lazyTab(() => import('@/components/DealsMonitor').then(m => m.DealsMonitor))
const PreOpen = lazyTab(() => import('@/components/PreOpen').then(m => m.PreOpen))
const IpoMonitor = lazyTab(() => import('@/components/IpoMonitor').then(m => m.IpoMonitor))
const LiveMovers = lazyTab(() => import('@/components/LiveMovers').then(m => m.LiveMovers))
const DailyWrap = lazyTab(() => import('@/components/DailyWrap').then(m => m.DailyWrap))
const CompanyFilings = lazyTab(() => import('@/components/CompanyFilings').then(m => m.CompanyFilings))
const MarginMonitor = lazyTab(() => import('@/components/MarginMonitor').then(m => m.MarginMonitor))
const FundamentalsScreen = lazyTab(() => import('@/components/FundamentalsScreen').then(m => m.FundamentalsScreen))
const AlertsCenter = lazyTab(() => import('@/components/AlertsCenter').then(m => m.AlertsCenter))
const EconomicCalendar = lazyTab(() => import('@/components/EconomicCalendar').then(m => m.EconomicCalendar))
const IndexMembers = lazyTab(() => import('@/components/IndexMembers').then(m => m.IndexMembers))
const OwnershipShifts = lazyTab(() => import('@/components/OwnershipShifts').then(m => m.OwnershipShifts))
const WorldMarkets = lazyTab(() => import('@/components/WorldMarkets').then(m => m.WorldMarkets))
const StockTable = lazyTab(() => import('@/components/StockTable').then(m => m.StockTable))
const SystemStatusWidget = lazyTab(() => import('@/components/SystemStatusWidget').then(m => m.SystemStatusWidget))
const SeasonalityPage = lazyTab(() => import('@/components/Seasonality').then(m => m.SeasonalityPage))
const ChartStudio = lazyTab(() => import('@/components/ChartStudio').then(m => m.ChartStudio))
const DerivativesDesk = lazyTab(() => import('@/components/DerivativesDesk').then(m => m.DerivativesDesk))
const StrategyBuilder = lazyTab(() => import('@/components/StrategyBuilder').then(m => m.StrategyBuilder))
const McxGoldDesk = lazyTab(() => import('@/components/McxGoldDesk').then(m => m.McxGoldDesk))
const RiskDashboard = lazyTab(() => import('@/components/RiskDashboard').then(m => m.RiskDashboard))
// the stock window opens over any tab; its chunk loads on first open
const StockDetailModal = dynamic(() => import('@/components/StockDetailModal').then(m => m.StockDetailModal),
  { loading: () => <Loading label="stock window" />, ssr: false })

import { OPEN_TICKER_EVENT, type TickerFocus } from '@/lib/openTicker'
import { GOTO_EVENT } from '@/lib/navigate'
import { Btn, Chip, ErrorBox, Grid, KV, Loading, Meter, PageHeader, Panel, ResearchNote, Stat, T, TabSkeleton, fmtInr, fmtSignedPct, tone } from '@/components/terminal'

type Tab = 'brief' | 'watch' | 'charts' | 'compare' | 'screen' | 'alerts' | 'eco' | 'seag' | 'memb' | 'options' | 'ostrategy' | 'derivatives' | 'insiders' | 'deals' | 'preopen' | 'ipo' | 'movers' | 'wrap' | 'filings' | 'margin' | 'holders' | 'world' | 'desk' | 'markets' | 'events' | 'overview' | 'stocks' | 'backtest' | 'positions' | 'broker' | 'pipeline' | 'scanner' | 'discovery' | 'commodity' | 'mcxgold' | 'glassbox' | 'mlengine' | 'explorer' | 'warehouse' | 'research' | 'risk' | 'system'

const FILTERS_INIT = { t1: false, t2: false, t3: false, t4: false, t5: false, t6: false, t7: false, t8: false }

const TAB_IDS: Tab[] = ['brief', 'watch', 'charts', 'compare', 'screen', 'alerts', 'eco', 'seag', 'memb', 'options', 'ostrategy', 'derivatives', 'insiders', 'deals', 'preopen', 'ipo', 'movers', 'wrap', 'filings', 'margin', 'holders', 'world', 'desk', 'markets', 'events', 'overview', 'stocks', 'backtest', 'positions', 'broker', 'pipeline', 'scanner',
  'discovery', 'commodity', 'mcxgold', 'glassbox', 'mlengine', 'explorer', 'warehouse', 'research', 'risk', 'system']

// Bloomberg-style function codes for the command bar ("/" or Ctrl/⌘+K)
const COMMAND_PAGES: CommandPage[] = [
  { id: 'brief',     code: 'BRF',   label: 'Morning brief',         hint: 'market, book, events, gold, news, system' },
  { id: 'watch',     code: 'WTCH',  label: 'Watch monitor',         hint: 'watchlist, pins, holdings: live quotes' },
  { id: 'charts',    code: 'CHRT',  label: 'Chart studio',          hint: 'candles, indicators, intraday VWAP' },
  { id: 'world',     code: 'WEI',   label: 'World markets',         hint: 'global indices, FX, commodities, rates' },
  { id: 'eco',       code: 'ECO',   label: 'Economic calendar',     hint: 'CPI, WPI, IIP, GDP releases · RBI and Fed decisions' },
  { id: 'memb',      code: 'MEMB',  label: 'Index members',         hint: 'NIFTY 50 / BANK / IT: weights, points, returns, P/E' },
  { id: 'seag',      code: 'SEAG',  label: 'Seasonality',           hint: 'average return by month · NIFTY, sectors, any stock' },
  { id: 'preopen',   code: 'PRE',   label: 'Pre-open auction',      hint: '09:00–09:08: IEP, gaps, order imbalance' },
  { id: 'movers',    code: 'MOV',   label: 'Live movers',           hint: 'intraday gainers, volume surges, 52w highs, sectors' },
  { id: 'filings',   code: 'CF',    label: 'Company filings',       hint: 'today\'s NSE announcements: results, orders, ratings…' },
  { id: 'options',   code: 'OMON',  label: 'Option monitor',        hint: 'live chain in market hours: OI walls, IV, PCR, max pain' },
  { id: 'derivatives', code: 'DERV', label: 'Derivatives desk',     hint: 'basis, rollover, PCR, VIX' },
  { id: 'ostrategy', code: 'OSTR',  label: 'Options strategies',    hint: 'payoffs, Greeks, breakevens' },
  { id: 'deals',     code: 'DEAL',  label: 'Block & bulk deals',    hint: 'named-client deals, netted, MF/insurer tagged' },
  { id: 'margin',    code: 'MRGN',  label: 'Margin monitor',        hint: 'MTF leverage build-ups and crowding' },
  { id: 'screen',    code: 'FUND',  label: 'Fundamentals screener', hint: 'P/E, growth, margin from NSE results filings' },
  { id: 'alerts',    code: 'ALRT',  label: 'Alerts',                hint: 'price alerts, fired history, notification inbox' },
  { id: 'holders',   code: 'HDS',   label: 'Ownership shifts',      hint: 'quarterly MF / FPI / promoter / retail changes' },
  { id: 'insiders',  code: 'INSD',  label: 'Insider monitor',       hint: 'promoter & director market buys' },
  { id: 'ipo',       code: 'IPO',   label: 'IPO monitor',           hint: 'open issues, subscription, listing scorecard' },
  { id: 'wrap',      code: 'WRAP',  label: 'Daily market wrap',     hint: 'end-of-day summary archive (21:00)' },
  { id: 'compare',   code: 'COMP',  label: 'Compare stocks',        hint: 'rebased performance, risk, correlation' },
  { id: 'desk',      code: 'DESK',  label: 'Decision Desk',         hint: 'monthly momentum allocator · paper' },
  { id: 'markets',   code: 'MKT',   label: 'Market Monitor',        hint: 'regime · breadth · sectors · movers' },
  { id: 'events',    code: 'EVTS',  label: 'Corporate calendar',    hint: 'results, dividends, splits, bonuses' },
  { id: 'overview',  code: 'OVRV',  label: 'Overview',              hint: 'universe and data health' },
  { id: 'stocks',    code: 'EQS',   label: 'Stocks / screener',     hint: 'T1–T8 filters, 1,500 NSE stocks' },
  { id: 'backtest',  code: 'BTST',  label: 'Backtest lab',          hint: 'walk-forward, real ICICI costs' },
  { id: 'positions', code: 'PORT',  label: 'Portfolio',             hint: 'LEGACY engine book (dormant) — live paper NAV is on DESK' },
  { id: 'broker',    code: 'BRKR',  label: 'Broker (ICICI)',        hint: 'holdings, positions, funds' },
  { id: 'pipeline',  code: 'PIPE',  label: 'Pipeline / watchlist',  hint: 'daily jobs and watchlist' },
  { id: 'scanner',   code: 'LWSC',  label: 'LW scanner',            hint: 'Larry Williams setups' },
  { id: 'discovery', code: 'ALFA',  label: 'Alpha discovery',       hint: 'hypothesis gauntlet' },
  { id: 'commodity', code: 'CMDT',  label: 'Commodities · Gold desk', hint: 'MCX gold pre-open fair value' },
  { id: 'mcxgold',   code: 'MCXG',  label: 'MCX gold desk',         hint: 'session, quotes, specs, paper ticket' },
  { id: 'glassbox',  code: 'GBOX',  label: 'Glass-Box studio',      hint: 'factor research, correlations' },
  { id: 'mlengine',  code: 'MLEN',  label: 'ML engine',             hint: 'models, labels, SHAP' },
  { id: 'explorer',  code: 'DEXP',  label: 'Data explorer',         hint: 'query DuckDB tables' },
  { id: 'warehouse', code: 'WHSE',  label: 'Warehouse health',      hint: 'NSE datasets and freshness' },
  { id: 'research',  code: 'RSCH',  label: 'Research library',      hint: 'every study and its verdict' },
  { id: 'risk',      code: 'RSK',   label: 'Risk dashboard',        hint: 'VaR, beta, stress, drawdown ladder' },
  { id: 'system',    code: 'SYS',   label: 'System telemetry',      hint: 'services, jobs, latency' },
]

function HomeContent() {
  const [view, setViewState] = useState<Tab>('brief')   // landing page: the morning brief
  // Deep links: ?tab=<id> selects a page (bookmarkable, used by scripts/ui_audit.py)
  useEffect(() => {
    const t = new URLSearchParams(window.location.search).get('tab') as Tab | null
    if (t && TAB_IDS.includes(t)) setViewState(t)
  }, [])
  const setView = useCallback((t: Tab) => {
    setViewState(t)
    const url = new URL(window.location.href)
    url.searchParams.set('tab', t)
    window.history.replaceState(null, '', url.toString())
  }, [])
  const { isDark, toggleTheme } = useTheme()
  const { watchlist, addToWatchlist, removeFromWatchlist, isWatched } = useWatchlist()
  const [dashboard, setDashboard] = useState<any>(null)
  const [enrichment, setEnrichment] = useState<any>(null)

  const [allStocks, setAllStocks] = useState<any[]>([])
  const [displayStocks, setDisplayStocks] = useState<any[]>([])
  const [totalStocks, setTotalStocks] = useState(0)
  const [isFiltered, setIsFiltered] = useState(false)
  const [filteredTotal, setFilteredTotal] = useState(0)

  const [selectedTicker, setSelectedTicker] = useState<string | null>(null)

  const [tickerFocus, setTickerFocus] = useState<TickerFocus | null>(null)
  // Browser tab title follows the page code (BRF · SuryaDhana, OMON · SuryaDhana …)
  useEffect(() => {
    const code = COMMAND_PAGES.find(p => p.id === view)?.code
    document.title = code ? `${code} · SuryaDhana` : 'SuryaDhana Terminal'
  }, [view])

  // Any component can open a stock with openTicker('TCS') (lib/openTicker.ts)
  useEffect(() => {
    const onOpen = (e: Event) => {
      const [t, f] = String((e as CustomEvent<string>).detail ?? '').split('|')
      if (t) { setTickerFocus((f as TickerFocus) || null); setSelectedTicker(t) }
    }
    window.addEventListener(OPEN_TICKER_EVENT, onOpen)
    return () => window.removeEventListener(OPEN_TICKER_EVENT, onOpen)
  }, [])
  useEffect(() => {
    const onGo = (e: Event) => {
      const t = (e as CustomEvent<string>).detail as Tab
      if (TAB_IDS.includes(t)) { setSelectedTicker(null); setView(t) }      // leaving a page closes the stock window
    }
    window.addEventListener(GOTO_EVENT, onGo)
    return () => window.removeEventListener(GOTO_EVENT, onGo)
  }, [setView])
  const [pageLoading, setPageLoading] = useState(true)
  const [filterLoading, setFilterLoading] = useState(false)
  const [refreshing, setRefreshing] = useState(false)
  const [showRefreshPanel, setShowRefreshPanel] = useState(false)
  const [refreshStatus, setRefreshStatus] = useState<any>(null)
  const [refreshError, setRefreshError] = useState<string | null>(null)
  const [bootstrapping, setBootstrapping] = useState(false)
  const [bootstrapResult, setBootstrapResult] = useState<any>(null)
  const [stocksPage, setStocksPage] = useState(0)
  const [technicalFilters, setTechnicalFilters] = useState(FILTERS_INIT)
  const [enriching, setEnriching] = useState(false)
  const [enrichProgress, setEnrichProgress] = useState<any>(null)

  // ── Initial load (with retry) ─────────────────────────────────────────────
  const [loadError, setLoadError] = useState<string | null>(null)
  const [retryCount, setRetryCount] = useState(0)

  const loadDashboard = useCallback(async () => {
    setPageLoading(true)
    setLoadError(null)
    try {
      const [dash, enrich, stocksRes] = await Promise.all([
        getDashboardSummary(),
        getEnrichmentStatus(),
        listStocks(0, 1500),
      ])
      setDashboard(dash.data)
      setEnrichment(enrich.data)
      const stocks = stocksRes.data?.stocks || []
      const total = stocksRes.data?.total || stocks.length
      setAllStocks(stocks)
      setDisplayStocks(stocks)
      setTotalStocks(total)
    } catch (err: any) {
      const msg = err?.message || 'Backend unreachable'
      setLoadError(msg)
      console.error('Failed to load dashboard:', err)
    } finally {
      setPageLoading(false)
    }
  }, [])

  useEffect(() => { loadDashboard() }, [loadDashboard, retryCount])

  // Auto-retry while the initial load is failing: without this, one failed load
  // (e.g. during a ui-api restart) left "BACKEND UNREACHABLE" on screen until the
  // user clicked Retry — even long after the backend was healthy again.
  useEffect(() => {
    if (!loadError) return
    const id = setTimeout(() => setRetryCount(c => c + 1), 10_000)
    return () => clearTimeout(id)
  }, [loadError, retryCount])

  // ── Screener filter ───────────────────────────────────────────────────────
  const applyTechnicalFilters = useCallback(async (filters: typeof FILTERS_INIT) => {
    setTechnicalFilters(filters)
    const anyActive = Object.values(filters).some(Boolean)

    if (!anyActive) {
      setIsFiltered(false)
      setDisplayStocks(allStocks)
      return
    }

    setFilterLoading(true)
    try {
      const byTicker = new Map(allStocks.map((stock) => [stock.ticker, stock]))
      // Page through ALL matches (backend caps a page at 500). Fetching only the first
      // 200 while the header showed the full total silently hid the rest.
      const PAGE = 500
      const first = await screenStocks(filters, 0, PAGE)
      const total: number = first.data?.total ?? 0
      let rows: any[] = first.data?.results || []
      for (let skip = PAGE; skip < total; skip += PAGE) {
        const next = await screenStocks(filters, skip, PAGE)
        rows = rows.concat(next.data?.results || [])
      }
      const res = { data: { total, results: rows } }
      const results = (res.data?.results || []).map((r: any) => ({
        // Neutral fallbacks ONLY when the universe list has no record for the ticker;
        // the real data-quality fields from allStocks must win (they used to be
        // overwritten with a fabricated "excellent / 95% / 0 days" on every row).
        total_rows: 0,
        first_date: '',
        years_of_data: 0,
        data_density_pct: 0,
        days_since_update: null,
        data_quality: 'unknown',
        ...(byTicker.get(r.ticker) || {}),
        ticker: r.ticker,
        latest_price: r.latest_price,
        price_date: r.price_date,
        latest_date: r.price_date,
        ma50: r.ma50,
        ma150: r.ma150,
        ma200: r.ma200,
        rs_rating: r.rs_rating,
        sepa_stage: r.sepa_stage,
        filters: r.filters,
      }))
      setIsFiltered(true)
      setFilteredTotal(res.data?.total || results.length)
      setDisplayStocks(results)
    } catch (err) {
      console.error('Screener error:', err)
    } finally {
      setFilterLoading(false)
    }
  }, [allStocks])

  // ── Load more ─────────────────────────────────────────────────────────────
  const loadMoreStocks = async () => {
    const nextPage = stocksPage + 1
    setStocksPage(nextPage)
    const res = await listStocks(nextPage * 100, 100)
    const newBatch = res.data?.stocks || []
    const combined = [...allStocks, ...newBatch]
    setAllStocks(combined)
    if (!isFiltered) setDisplayStocks(combined)
  }

  // ── Bootstrap universe (cold-start: fetch Nifty 500 list from NSE) ─────────
  const handleBootstrap = async () => {
    setBootstrapping(true)
    setBootstrapResult(null)
    setRefreshError(null)
    try {
      const res = await bootstrapUniverse()
      setBootstrapResult(res.data)
      // Auto-trigger OHLCV refresh after successful bootstrap
      if (res.data?.status === 'bootstrapped') {
        setTimeout(() => handleRefresh(), 500)
      }
    } catch (err: any) {
      setRefreshError(apiError(err, 'Bootstrap failed. Check your internet connection.'))
    } finally {
      setBootstrapping(false)
    }
  }

  // ── Refresh: smart incremental OHLCV download ────────────────────────────
  const handleRefresh = async () => {
    if (refreshing) {
      setShowRefreshPanel(true)
      return
    }
    setRefreshing(true)
    setShowRefreshPanel(true)
    setRefreshStatus(null)
    setRefreshError(null)
    try {
      const triggerRes = await triggerRefresh({ universe: 'nse_1500', years: 5 })
      const data = triggerRes.data

      // Backend signals no universe exists — show setup guidance
      if (data?.status === 'no_universe') {
        setRefreshError(data.message || 'No universe data found. Bootstrap first.')
        setRefreshing(false)
        return
      }

      // Poll progress every 3 seconds until done
      const poll = async () => {
        try {
          const res = await getRefreshStatus()
          setRefreshStatus(res.data)
          if (res.data?.active) {
            setTimeout(poll, 3000)
          } else {
            setRefreshing(false)
            // Re-fetch dashboard after completion
            const [dash, enrich, stocksRes] = await Promise.all([
              getDashboardSummary(),
              getEnrichmentStatus(),
              listStocks(0, 1500),
            ])
            setDashboard(dash.data)
            setEnrichment(enrich.data)
            const stocks = stocksRes.data?.stocks || []
            setAllStocks(stocks)
            setDisplayStocks(stocks)
            setTotalStocks(stocksRes.data?.total || stocks.length)
            setStocksPage(0)
          }
        } catch {
          setRefreshing(false)
        }
      }
      setTimeout(poll, 2000)
    } catch (err) {
      console.error('Refresh error:', err)
      setRefreshing(false)
    }
  }

  // ── Enrich fundamentals (PE, MCap, NP QTR, Sales, ROCE) ─────────────────
  const handleEnrich = async () => {
    if (enriching) return
    setEnriching(true)
    setEnrichProgress(null)
    try {
      await triggerEnrich()
      const poll = async () => {
        try {
          const res = await getEnrichProgress()
          setEnrichProgress(res.data)
          if (res.data?.active) {
            setTimeout(poll, 5000)
          } else {
            setEnriching(false)
            const dash = await getDashboardSummary()
            setDashboard(dash.data)
          }
        } catch { setEnriching(false) }
      }
      setTimeout(poll, 2000)
    } catch { setEnriching(false) }
  }

  const activeFilterCount = Object.values(technicalFilters).filter(Boolean).length
  const displayCount = isFiltered ? filteredTotal : totalStocks

  // Build tab descriptor list for MarketCommandHeader
  const tabList = [
    { id: 'brief',     label: 'Brief' },
    { id: 'watch',     label: 'Watch' },
    { id: 'desk',      label: 'Desk' },
    { id: 'markets',   label: 'Markets' },
    { id: 'derivatives', label: 'Deriv' },
    { id: 'events',    label: 'Events' },
    { id: 'overview',  label: 'Overview' },
    { id: 'stocks',    label: 'Stocks',       badge: activeFilterCount || undefined },
    { id: 'backtest',  label: 'Backtest' },
    { id: 'positions', label: 'Portfolio' },
    { id: 'broker',    label: 'Broker' },
    { id: 'pipeline',  label: 'Pipeline',     badge: watchlist.length || undefined },
    { id: 'scanner',   label: 'LW Scan' },
    { id: 'discovery', label: 'Alpha' },
    { id: 'commodity', label: 'Commodity' },
    { id: 'glassbox',  label: 'Glass-Box' },
    { id: 'mlengine',  label: 'ML' },        // 'ML Engine' truncated to 'ML E…' at common widths
    { id: 'explorer',  label: 'Explorer' },
    { id: 'warehouse', label: 'Warehouse' },
    { id: 'research',  label: 'Research' },
    { id: 'system',    label: 'System' },
  ]

  return (
    <div style={{ minHeight: '100vh', background: 'var(--t-bg)', color: 'var(--t-text)', paddingBottom: 30 }}>
      {/* ── NSE Operations Center Command Header ───────────────────────── */}
      <MarketCommandHeader
        onRefresh={handleRefresh}
        refreshing={refreshing}
        totalStocks={dashboard?.total_stocks ?? totalStocks}
        latestDate={dashboard?.latest_date}
        activeTab={view}
        tabs={tabList}
        more={COMMAND_PAGES.filter(p => !tabList.some(t => t.id === p.id))}
        onTabChange={(id) => setView(id as Tab)}
      />

      {/* ── Refresh / Setup Panel ───────────────────────────────────────── */}
      {showRefreshPanel && (
        <div className={clsx('border-b', isDark ? 'border-indigo-900/50 bg-indigo-950/30' : 'border-indigo-100 bg-indigo-50')}>
          <div className="w-full px-4 sm:px-6 lg:px-8 py-4">
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center gap-3">
                {(refreshing || bootstrapping) && (
                  <span className="w-3 h-3 border-2 border-indigo-500 border-t-transparent rounded-full animate-spin" />
                )}
                <span className={clsx(
                  'text-sm font-bold',
                  refreshError ? 'text-amber-700' : isDark ? 'text-indigo-300' : 'text-indigo-800'
                )}>
                  {bootstrapping
                    ? 'Bootstrapping NSE 500 universe from niftyindices.com…'
                    : refreshError
                    ? 'Setup required — no stock data found'
                    : refreshing
                    ? `Downloading 5yr OHLCV from NSE via yfinance…`
                    : refreshStatus?.total > 0
                    ? `Done — ${refreshStatus.done}/${refreshStatus.total} stocks updated`
                    : 'Refresh complete'}
                </span>
                {refreshStatus && !refreshError && (
                  <span className="text-xs text-indigo-600">
                    {refreshStatus.done} done · {refreshStatus.downloading} active · {refreshStatus.pending} pending
                    {refreshStatus.errors > 0 && ` · ${refreshStatus.errors} errors`}
                  </span>
                )}
              </div>
              <button
                onClick={() => { setShowRefreshPanel(false); setRefreshError(null); setBootstrapResult(null) }}
                className={clsx('text-sm font-medium', isDark ? 'text-indigo-400 hover:text-indigo-200' : 'text-indigo-400 hover:text-indigo-700')}
              >
                Close
              </button>
            </div>

            {/* ── No-universe setup guidance ─────────────────────────────── */}
            {refreshError && (
              <div className={clsx('rounded-lg p-4 mb-3 border', isDark ? 'bg-amber-950/40 border-amber-700/50' : 'bg-amber-50 border-amber-200')}>
                <p className={clsx('text-xs mb-3', isDark ? 'text-amber-300' : 'text-amber-800')}>
                  The database is empty and no universe CSV was found. Choose a setup path:
                </p>
                <div className="flex flex-wrap gap-3">
                  {/* Option A: Quick bootstrap from NSE */}
                  <button
                    onClick={handleBootstrap}
                    disabled={bootstrapping}
                    className={clsx(
                      'flex items-center gap-2 px-4 py-2 rounded-lg text-xs font-bold border transition-all',
                      bootstrapping
                        ? 'bg-emerald-50 border-emerald-200 text-emerald-400 cursor-not-allowed'
                        : 'bg-emerald-600 border-emerald-600 text-white hover:bg-emerald-700 shadow-sm'
                    )}
                  >
                    {bootstrapping ? '↻ Fetching…' : '⚡ Quick Bootstrap (Nifty 500)'}
                  </button>
                  {/* Option B: Manual terminal steps */}
                  <div className={clsx('text-xs rounded-lg px-3 py-2 border font-mono', isDark ? 'bg-slate-900 border-slate-700 text-slate-300' : 'bg-white border-gray-200 text-gray-700')}>
                    <span className="text-gray-400">Or run in terminal:</span>
                    <br />
                    <span className="text-emerald-500">python</span> scripts/nifty500_pipeline.py <span className="text-amber-400">--mode universe1500</span>
                    <br />
                    <span className="text-emerald-500">python</span> scripts/nifty500_pipeline.py <span className="text-amber-400">--mode initial</span>
                  </div>
                </div>
                {bootstrapResult && (
                  <p className={clsx('text-xs mt-2 font-semibold', isDark ? 'text-emerald-400' : 'text-emerald-700')}>
                    ✓ {bootstrapResult.tickers} tickers loaded — downloading OHLCV data now…
                  </p>
                )}
              </div>
            )}

            {/* ── Progress bar ───────────────────────────────────────────── */}
            {refreshStatus?.total > 0 && (
              <div className="w-full h-2 rounded-full bg-indigo-200 overflow-hidden mb-3">
                <div
                  className="h-full bg-indigo-600 rounded-full transition-all duration-500"
                  style={{ width: `${refreshStatus.pct}%` }}
                />
              </div>
            )}

            {/* ── Per-ticker status badges ────────────────────────────────── */}
            {refreshStatus?.tickers && Object.keys(refreshStatus.tickers).length > 0 && (
              <div className="flex flex-wrap gap-1 max-h-28 overflow-y-auto">
                {Object.entries(refreshStatus.tickers as Record<string, string>).map(([t, status]) => (
                  <span
                    key={t}
                    className={clsx(
                      'text-xs px-1.5 py-0.5 rounded font-mono',
                      status === 'done'        ? 'bg-emerald-100 text-emerald-700' :
                      status === 'downloading' ? 'bg-indigo-200 text-indigo-700 animate-pulse' :
                      status === 'error'       ? 'bg-rose-100 text-rose-600' :
                                                 'bg-gray-100 text-gray-400'
                    )}
                  >
                    {t}
                  </span>
                ))}
              </div>
            )}

            {!refreshStatus && refreshing && (
              <p className={clsx('text-xs', isDark ? 'text-indigo-400' : 'text-indigo-500')}>
                Fetching 5yr NSE OHLCV from yfinance (.NS suffix) — incremental, only missing dates downloaded per ticker…
              </p>
            )}
          </div>
        </div>
      )}

      {/* ── Live Monitor Bar ────────────────────────────────────────────── */}
      <LiveMonitorBar isDark={isDark} />

      {/* ── Main Content ────────────────────────────────────────────────── */}
      <main style={{ padding: '12px 14px' }}>
        {pageLoading ? (
          <Loading label="Connecting to SuryaDhana services" />
        ) : loadError ? (
          <Panel title="Backend unreachable" accent="#ff4d5e">
            <ErrorBox error={`${loadError}: ui-api may be starting up (auto-retry every 10 s)`}
                      onRetry={() => setRetryCount(c => c + 1)} />
          </Panel>
        ) : (
          <>
            {view === 'overview' && (
              <OverviewTab
                dashboard={dashboard}
                enrichment={enrichment}
                totalStocks={totalStocks}
                isDark={isDark}
                enriching={enriching}
                enrichProgress={enrichProgress}
                onEnrich={handleEnrich}
              />
            )}
            {view === 'stocks' && (
              <StocksTab
                displayStocks={displayStocks}
                displayCount={displayCount}
                isFiltered={isFiltered}
                filterLoading={filterLoading}
                technicalFilters={technicalFilters}
                allStocksCount={allStocks.length}
                totalStocks={totalStocks}
                onFilterChange={applyTechnicalFilters}
                onRowClick={setSelectedTicker}
                onLoadMore={loadMoreStocks}
                isDark={isDark}
                watchlist={watchlist}
                onWatchToggle={(ticker: string) => isWatched(ticker) ? removeFromWatchlist(ticker) : addToWatchlist(ticker)}
              />
            )}
            {view === 'backtest' && <BacktestPanel isDark={isDark} watchlist={watchlist} />}
            {view === 'positions' && <LivePortfolio isDark={isDark} />}
            {view === 'broker' && <PortfolioSummary />}
            {view === 'brief' && <Brief onNavigate={id => setView(id as Tab)} />}
            {view === 'watch' && <WatchMonitor />}
            {view === 'compare' && <Compare />}
            {view === 'charts' && <ChartStudio />}
            {view === 'options' && <OptionChain />}
            {view === 'ostrategy' && <StrategyBuilder />}
            {view === 'insiders' && <InsiderMonitor />}
            {view === 'deals' && <DealsMonitor />}
            {view === 'preopen' && <PreOpen />}
            {view === 'ipo' && <IpoMonitor />}
            {view === 'movers' && <LiveMovers />}
            {view === 'wrap' && <DailyWrap />}
            {view === 'filings' && <CompanyFilings />}
            {view === 'margin' && <MarginMonitor />}
            {view === 'screen' && <FundamentalsScreen />}
            {view === 'alerts' && <AlertsCenter />}
            {view === 'eco' && <EconomicCalendar />}
            {view === 'seag' && <SeasonalityPage />}
            {view === 'memb' && <IndexMembers />}
            {view === 'holders' && <OwnershipShifts />}
            {view === 'world' && <WorldMarkets />}
            {view === 'desk' && <DecisionDesk isDark={isDark} />}
            {view === 'risk' && <RiskDashboard isDark={isDark} />}
            {view === 'markets' && <MarketMonitor onSelectTicker={setSelectedTicker} />}
            {view === 'derivatives' && <DerivativesDesk onSelectTicker={setSelectedTicker} />}
            {view === 'events' && <EventCalendar onSelectTicker={setSelectedTicker} />}
            {view === 'scanner' && <LWScanner />}
            {view === 'discovery' && <AlphaDiscoveryDesk isDark={isDark} />}
            {view === 'commodity' && <CommodityTab isDark={isDark} />}
            {view === 'mcxgold' && <McxGoldDesk />}
            {view === 'glassbox' && (
              <>
                <PageHeader code="GBOX" title="Glass-Box Studio"
                            subtitle="Relative rotation · rolling correlation + squeeze · volume profile" />
                <GlassBoxStudio isDark={isDark} />
              </>
            )}
            {view === 'mlengine' && (
              <>
                <PageHeader code="MLEN" title="ML Engine"
                            subtitle="Live XGBoost direction-model training · streaming convergence · kill-switch" />
                <ResearchNote verdict="FAIL" report="reports/ml_labels/FINDINGS.md">
                  The best labels (20-session excess rank) beat the old 5-day labels, but the ML top-20 book still trails plain
                  Desk momentum after costs, and NSE flow features add nothing. Train here for research, not for trading.
                </ResearchNote>
                <MLEngineWorkspace isDark={isDark} />
              </>
            )}
            {view === 'explorer' && (
              <>
                <PageHeader code="DEXP" title="Data Explorer"
                            subtitle="Paginated feature grid · sort · filter by ticker · data health" />
                <DataExplorerTab />
              </>
            )}
            {view === 'warehouse' && <WarehouseHealth isDark={isDark} />}
            {view === 'research' && <ResearchLibrary />}
            {view === 'system' && <SystemTelemetry isDark={isDark} />}
            {/* PipelineStudio stays mounted once first visited — preserves training state */}
            <div style={{ display: view === 'pipeline' ? 'block' : 'none' }}>
              <PipelineStudio isDark={isDark} watchlist={watchlist} />
            </div>
          </>
        )}
      </main>

      {/* ── Status line (Bloomberg-style) ─────────────────────────────── */}
      <footer style={{ position: 'fixed', bottom: 0, left: 0, right: 0, height: 22, zIndex: Z.footer, display: 'flex',
                       alignItems: 'center', gap: 14, padding: '0 12px', fontSize: 9.5, letterSpacing: 1.1,
                       borderTop: '1px solid var(--t-border)', background: '#07090d', color: 'var(--t-muted)' }}>
        <span style={{ color: loadError ? 'var(--t-red)' : 'var(--t-green)' }}>● {loadError ? 'OFFLINE' : 'READY'}</span>
        <span>DATA {dashboard?.latest_date ?? '—'}</span>
        <span>{(dashboard?.total_stocks ?? totalStocks).toLocaleString('en-IN')} STOCKS</span>
        <span style={{ flex: 1 }} />
        {/* News Catalyst Terminal: docked as a status-line segment on every tab */}
        <NewsDock />
        <button onClick={() => window.dispatchEvent(new Event('suryadhana:command'))} title="Command bar (/ or Ctrl+K)"
          style={{ background: 'none', border: 'none', padding: 0, cursor: 'pointer', color: 'var(--t-amber)',
                   font: 'inherit', letterSpacing: 'inherit' }}>/ GO</button>
        <span>ALT+1…0 PAGES · SHIFT+N NEWS · ? HELP · ESC CLOSE</span>
        <span style={{ color: 'var(--t-dim)' }}>SURYADHANA TERMINAL · NSE · PAPER</span>
      </footer>

      <CommandBar pages={COMMAND_PAGES} onPage={id => { setSelectedTicker(null); setView(id as Tab) }} onTicker={setSelectedTicker} />

      {selectedTicker && (
        <StockDetailModal ticker={selectedTicker} focus={tickerFocus} onClose={() => { setSelectedTicker(null); setTickerFocus(null) }} />
      )}
    </div>
  )
}

// ── Overview Tab ──────────────────────────────────────────────────────────────
const ROADMAP: { phase: string; label: string; detail: string; status: 'done' | 'active' | 'next' | 'later' }[] = [
  { phase: 'A', label: 'Costs · data · tax', detail: 'Real ICICI costs, NSE bhavcopy 2010→ (survivorship-free)', status: 'done' },
  { phase: 'B', label: 'Strategy research', detail: 'Momentum beats NIFTY after costs+tax, 2011–2026', status: 'done' },
  { phase: 'C', label: 'Decision Desk (paper)', detail: 'Monthly brief · paper fills · emergency stop', status: 'active' },
  { phase: 'D', label: 'India-specific signals', detail: 'Delivery %, bulk/block deals, insider buys, news scoring', status: 'next' },
  { phase: 'E', label: 'Small live', detail: 'After ≥ 3 months of paper inside the tracking band', status: 'later' },
]

function DeskSnapshot() {
  const [d, setD] = useState<any>(null)
  useEffect(() => { getDeskStatus().then(r => setD(r.data)).catch(() => setD(null)) }, [])
  const nav = d?.latest?.nav ?? d?.meta?.start_capital
  const start = d?.meta?.start_capital
  const plan = d?.plans?.[0]
  return (
    <Panel title="Decision Desk" subtitle="paper book · monthly momentum"
      right={<Chip color={T.amber} active>PAPER</Chip>}>
      {!d ? <Loading label="Loading book" /> : (
        <KV items={[
          ['Book value', fmtInr(nav)],
          ['Return', fmtSignedPct(start ? (nav / start - 1) * 100 : null), tone(nav - start)],
          ['Positions', `${d.positions?.length ?? 0} / 20`],
          ['Latest brief', plan ? `${plan.plan_id} · ${plan.status}` : 'after month-end (19:30 IST)'],
          ['Crash filter', plan ? (plan.summary?.risk_on ? 'OFF · invested' : 'ON · liquid fund') : '—',
           plan ? (plan.summary?.risk_on ? T.green : T.amber) : undefined],
          ['Last marked', d.meta?.last_mark ?? '—'],
        ]} />
      )}
    </Panel>
  )
}

function OverviewTab({ dashboard, totalStocks, enriching, enrichProgress, onEnrich }: any) {
  const fresh = dashboard?.freshness?.fresh ?? 0
  const behind = dashboard?.freshness?.stale ?? 0
  const aged = dashboard?.freshness?.very_stale ?? 0
  const freshPct = dashboard?.freshness?.fresh_pct ?? 0
  const enriched = dashboard?.enrichment?.enriched ?? 0
  const enrichTotal = dashboard?.enrichment?.total ?? totalStocks
  const enrichPct = dashboard?.enrichment?.enrichment_pct ?? 0
  // quarterly financials read straight from NSE results filings (FA cache): companies covered
  const [faCount, setFaCount] = useState<number | null>(null)
  useEffect(() => { getArchiveMeta().then(r => setFaCount(r.data['archive:financials']?.rows ?? 0)).catch(() => {}) }, [])
  const universeSize = dashboard?.universe_size ?? 0
  const coveragePct = dashboard?.coverage_pct ?? 0
  const universeLabel = (dashboard?.universe_label ?? 'nse_500').replace('nse_', 'NSE ').toUpperCase()
  const dbCount = dashboard?.total_stocks ?? totalStocks
  const pct = (n: number) => (n / Math.max(dbCount, 1)) * 100
  const statusColor = { done: T.green, active: T.amber, next: T.cyan, later: T.dim }
  const statusMark = { done: '✓', active: '▶', next: '›', later: '○' }

  return (
    <div>
      <PageHeader code="OVRV" title="Overview" subtitle={`${universeLabel} universe · data through ${dashboard?.latest_date ?? '—'}`} />
      <div style={{ display: 'grid', gap: 10 }}>
        <Grid cols={5}>
          <Stat label="Universe" value={universeSize.toLocaleString('en-IN')} sub={universeLabel} accent={T.cyan} />
          <Stat label="In database" value={dbCount.toLocaleString('en-IN')} sub={`${coveragePct}% coverage`} accent={T.violet} />
          <Stat label="Latest session" value={dashboard?.latest_date ?? '—'} sub={`${freshPct}% of stocks current`}
                accent={freshPct >= 95 ? T.green : T.amber} color={T.bright} />
          <Stat label="History from" value={dashboard?.data_range?.from?.slice(0, 7) ?? '—'} sub={`→ ${dashboard?.data_range?.to ?? '—'} (Yahoo)`} />
          <Stat label="Fundamentals" value={`${enrichPct}%`} sub={`${enriched.toLocaleString('en-IN')} of ${enrichTotal.toLocaleString('en-IN')} enriched`} accent={T.violet} />
        </Grid>

        <Panel title="Data freshness" subtitle={`${dbCount.toLocaleString('en-IN')} stocks · measured in trading sessions behind the latest close`}
          right={<Chip color={freshPct >= 95 ? T.green : freshPct >= 80 ? T.amber : T.red} active>{freshPct}% CURRENT</Chip>}>
          <div style={{ display: 'flex', height: 6, background: T.border, marginBottom: 12 }}>
            <div style={{ width: `${pct(fresh)}%`, background: T.green }} />
            <div style={{ width: `${pct(behind)}%`, background: T.amber }} />
            <div style={{ width: `${pct(aged)}%`, background: T.red }} />
          </div>
          <Grid cols={3}>
            <Stat label="At latest session" value={fresh.toLocaleString('en-IN')} color={T.green} sub="updated at the last close" big={false} />
            <Stat label="1–5 sessions behind" value={behind.toLocaleString('en-IN')} color={T.amber} sub="missed a recent refresh" big={false} />
            <Stat label="> 5 sessions behind" value={aged.toLocaleString('en-IN')} color={T.red} sub="suspended / delisted / renamed" big={false} />
          </Grid>
        </Panel>

        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, minmax(0, 1fr))', gap: 10 }}>
          <DeskSnapshot />
          <Panel title="Roadmap" subtitle="docs/PRODUCT_STRATEGY.md">
            <div style={{ display: 'grid', gap: 6 }}>
              {ROADMAP.map(r => (
                <div key={r.phase} style={{ display: 'grid', gridTemplateColumns: '22px 1fr', gap: 8, padding: '6px 8px',
                                            borderLeft: `2px solid ${statusColor[r.status]}`, background: '#080b10' }}>
                  <span style={{ color: statusColor[r.status], fontWeight: 700 }}>{statusMark[r.status]}</span>
                  <div>
                    <div style={{ fontSize: 11, color: T.bright }}>
                      <span style={{ color: statusColor[r.status] }}>{r.phase}</span> · {r.label}
                      <span style={{ fontSize: 9, color: statusColor[r.status], marginLeft: 8, letterSpacing: 1 }}>{r.status.toUpperCase()}</span>
                    </div>
                    <div style={{ fontSize: 10, color: T.muted, marginTop: 2 }}>{r.detail}</div>
                  </div>
                </div>
              ))}
            </div>
          </Panel>
          <SystemStatusWidget />
        </div>

        <Panel title="Fundamentals enrichment" subtitle="PE · market cap · quarterly profit & sales · ROCE (snapshot, not point-in-time)"
          right={<Btn size="sm" onClick={onEnrich} disabled={enriching}>{enriching ? 'Enriching…' : enriched === 0 ? '⚡ Enrich now' : '↻ Re-enrich'}</Btn>}>
          <Meter value={enrichPct / 100} color={T.violet} />
          <div style={{ fontSize: 10.5, color: T.muted, marginTop: 6 }}>
            {enriched.toLocaleString('en-IN')} of {enrichTotal.toLocaleString('en-IN')} stocks have the snapshot (STOCKS columns).
            {faCount != null && <> Quarterly financials from NSE&apos;s own results filings: <span style={{ color: T.text }}>{faCount.toLocaleString('en-IN')} companies</span>
              {' '}<span role="button" onClick={() => goToPage('screen')} style={{ color: T.cyan, cursor: 'pointer' }}>FUND ›</span></>}
          </div>
          {enriching && enrichProgress && (
            <div style={{ fontSize: 10, color: T.violet, marginTop: 6 }}>
              {enrichProgress.done?.toLocaleString()} / {enrichProgress.total?.toLocaleString()} · {enrichProgress.pct}%
            </div>
          )}
        </Panel>
      </div>
    </div>
  )
}

// ── Stocks Tab ────────────────────────────────────────────────────────────────
function StocksTab({
  displayStocks, displayCount, isFiltered, filterLoading, technicalFilters,
  allStocksCount, totalStocks, onFilterChange, onRowClick, onLoadMore, isDark = true,
  watchlist = [], onWatchToggle,
}: any) {
  // Scoped refresh — updates ONLY the watchlist tickers (not the full universe)
  const [wlBusy, setWlBusy] = useState(false)
  const [wlMsg, setWlMsg]   = useState('')
  const doRefreshWatchlist = async () => {
    if (!watchlist.length || wlBusy) return
    setWlBusy(true); setWlMsg(`Queuing ${watchlist.length}…`)
    try {
      await refreshWatchlist(watchlist)
      const poll = async (n = 0) => {
        try {
          const s = (await getRefreshStatus()).data
          const done = (s.done ?? 0) + (s.current ?? 0)
          if (s.active && n < 40) { setWlMsg(`${done}/${s.total} updated…`); setTimeout(() => poll(n + 1), 1500) }
          else { setWlMsg(`✓ ${done || watchlist.length}/${s.total || watchlist.length} updated`); setWlBusy(false) }
        } catch { setWlMsg('✓ refresh queued'); setWlBusy(false) }
      }
      setTimeout(() => poll(), 1200)
    } catch (e: any) {
      setWlMsg('⚠ ' + (apiError(e, 'refresh failed'))); setWlBusy(false)
    }
  }

  const FILTERS = [
    { key: 't1', label: 'T1', desc: 'Price > 150/200 MA' },
    { key: 't2', label: 'T2', desc: '150 MA > 200 MA' },
    { key: 't3', label: 'T3', desc: '200 MA Uptrend 1M+' },
    { key: 't4', label: 'T4', desc: '50 MA > 150/200 MA' },
    { key: 't5', label: 'T5', desc: 'Price > 50 MA' },
    { key: 't6', label: 'T6', desc: 'Price ≥30% above 52W low' },
    { key: 't7', label: 'T7', desc: 'Price within 25% of 52W high' },
    { key: 't8', label: 'T8', desc: 'RS Rating ≥70' },
  ]

  const toggle = (key: string) => {
    const next = { ...technicalFilters, [key]: !technicalFilters[key] }
    onFilterChange(next)
  }

  const clearAll = () => onFilterChange({ t1: false, t2: false, t3: false, t4: false, t5: false, t6: false, t7: false, t8: false })
  // One click, one screener query (eight separate clicks used to fire eight).
  const selectAll = () => onFilterChange({ t1: true, t2: true, t3: true, t4: true, t5: true, t6: true, t7: true, t8: true })
  const activeCount = Object.values(technicalFilters).filter(Boolean).length
  const allOn = activeCount === FILTERS.length

  return (
    <div>
      <PageHeader code="EQS" title="Stocks"
        subtitle={isFiltered ? `${displayCount} match ${activeCount} Minervini filter${activeCount > 1 ? 's' : ''}` : `${allStocksCount.toLocaleString('en-IN')} of ${totalStocks.toLocaleString('en-IN')} NSE stocks`}
        right={activeCount > 0 ? <Btn size="sm" onClick={clearAll}>Clear filters ({activeCount})</Btn> : undefined} />
      <div style={{ display: 'grid', gap: 10 }}>
        <Panel title="Minervini trend template" subtitle="all active filters must pass · T1+T2 = Stage-2 trend"
          right={<Btn size="sm" variant={allOn ? 'ghost' : 'primary'} onClick={allOn ? clearAll : selectAll}
                   disabled={filterLoading}
                   title={allOn ? 'Turn every filter off' : 'Turn on T1–T8 at once: the full Minervini trend template'}>
                   {allOn ? '□ Clear all' : '■ Select all T1–T8'}
                 </Btn>}>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(8, minmax(0, 1fr))', gap: 6 }}>
            {FILTERS.map(({ key, label, desc }) => {
              const on = (technicalFilters as any)[key]
              return (
                <button key={key} onClick={() => toggle(key)}
                  style={{ textAlign: 'left', padding: '8px 10px', cursor: 'pointer', border: `1px solid ${on ? T.amber : T.border}`,
                           background: on ? 'rgba(255,176,0,.12)' : '#080b10', fontFamily: T.mono }}>
                  <div style={{ fontSize: 12, fontWeight: 700, color: on ? T.amber : T.text }}>{on ? '■' : '□'} {label}</div>
                  <div style={{ fontSize: 10, color: on ? T.amber : T.muted, marginTop: 3, lineHeight: 1.35 }}>{desc}</div>
                </button>
              )
            })}
          </div>
        </Panel>

        {watchlist.length > 0 && (
          <Panel title={`Watchlist (${watchlist.length})`} subtitle="syncs to Backtest & Pipeline" accent={T.cyan}
            right={<>
              {wlMsg && <span style={{ fontSize: 10, color: T.cyan }}>{wlMsg}</span>}
              <Btn size="sm" onClick={doRefreshWatchlist} disabled={wlBusy}>{wlBusy ? 'Refreshing…' : `↻ Refresh ${watchlist.length}`}</Btn>
            </>}>
            <div style={{ display: 'flex', gap: 6, flexWrap: 'wrap' }}>
              {watchlist.map((t: string) => (
                <Chip key={t} color={T.cyan}>{t}
                  <span onClick={() => onWatchToggle(t)} style={{ color: T.dim, cursor: 'pointer' }} title="Remove">×</span>
                </Chip>
              ))}
            </div>
          </Panel>
        )}

        <Panel title={isFiltered ? 'Screener results' : 'All stocks'} pad={0}
          subtitle={isFiltered ? `${displayCount} matched` : `${allStocksCount} of ${totalStocks} loaded · click a row for the chart`}
          right={filterLoading ? <span style={{ fontSize: 10, color: T.amber }} className="t-pulse">FILTERING…</span> : undefined}>
          <StockTable stocks={displayStocks} onRowClick={onRowClick} loading={filterLoading} isDark={isDark} watchlist={watchlist} onWatchToggle={onWatchToggle} />
          {!isFiltered && allStocksCount < totalStocks && (
            <div style={{ padding: 12, textAlign: 'center', borderTop: `1px solid ${T.border}` }}>
              <Btn onClick={onLoadMore}>Load more ({totalStocks - allStocksCount} remaining)</Btn>
            </div>
          )}
        </Panel>
      </div>
    </div>
  )
}

export default function Home() {
  return (
    <ThemeProvider>
      <AppProvider>
        <ToastProvider>
          <ErrorCatcher />
          <HomeContent />
        </ToastProvider>
      </AppProvider>
    </ThemeProvider>
  )
}

