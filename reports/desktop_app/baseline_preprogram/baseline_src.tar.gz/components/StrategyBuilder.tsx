'use client'

/**
 * OSTR — options strategy builder (W3). Build up to 4 legs (buy/sell · CE/PE/FUT) seeded
 * from the cached EOD option chain, price them with the backend engine
 * (POST /api/options/strategy/analyze: Black-76 Greeks, EXACT breakevens, bounded/unbounded
 * max P&L, margin + NSE-cost ESTIMATES) and draw the payoff to scale.
 *
 * PRICES ONLY — paper terminal: there is no order button here and never will be.
 * Chain: GET /api/market/option-chain/{symbol} (NSE F&O bhavcopy, works at any hour —
 * no broker session involved).
 */
import axios from 'axios'
import { useCallback, useEffect, useMemo, useRef, useState } from 'react'
import { getOptionChain, type OptionChain as Chain } from '@/lib/api'
import { Btn, Chip, ErrorBox, Input, Label, Loading, Notice, PageHeader, Panel, Select, Stat, T, fmtInr } from '@/components/terminal'

// ── types ───────────────────────────────────────────────────────────────────────

type Side = 'buy' | 'sell'
type Kind = 'CE' | 'PE' | 'FUT'
interface UiLeg { id: number; side: Side; kind: Kind; strike: number | null; premium: string; iv: string; lots: string }

interface Analysis {
  entry_cashflow: number; net_label: 'CREDIT' | 'DEBIT' | 'FLAT'; single_expiry: boolean
  breakevens: number[]
  max_profit: { value: number | null; unbounded: boolean; at: number | null }
  max_loss: { value: number | null; unbounded: boolean; at: number | null }
  greeks: { per_leg: Record<string, number | null>[]; net: Record<string, number>; note: string }
  payoff: { s: number; expiry: number; now: number }[]
  margin: { estimate: boolean; total: number; per_leg: number[]; premium_outflow: number
            defined_risk_floor: number | null; fut_margin_pct: number; note: string }
  costs: { estimate: boolean; entry: number; exit: number; round_trip: Record<string, number>; note: string }
}

const n2 = (v: number | null | undefined, d = 2) =>
  v == null || !Number.isFinite(v) ? '—' : v.toLocaleString('en-IN', { minimumFractionDigits: d, maximumFractionDigits: d })

// ── template seeding (strikes picked from the chain so every leg is tradeable) ──

const TEMPLATES = [
  'Long call', 'Long put', 'Bull call spread', 'Bear put spread',
  'Straddle', 'Strangle', 'Iron condor', 'Covered call (fut+CE)',
] as const
type Template = typeof TEMPLATES[number]

let legSeq = 1
const mk = (side: Side, kind: Kind, strike: number | null, premium: number | null, iv: number | null): UiLeg =>
  ({ id: legSeq++, side, kind, strike, premium: premium != null ? String(premium) : '', iv: iv != null ? String(iv) : '', lots: '1' })

/** price + IV for a strike from the chain; IV falls back to the other side (parity) then ATM. */
function fromChain(chain: Chain, strike: number, kind: 'CE' | 'PE'): { premium: number | null; iv: number | null } {
  const row = chain.rows.find(r => r.strike === strike)
  if (!row) return { premium: null, iv: chain.atm_iv }
  const leg = kind === 'CE' ? row.ce : row.pe, other = kind === 'CE' ? row.pe : row.ce
  return { premium: leg.price, iv: leg.iv ?? other.iv ?? chain.atm_iv }
}

function seedTemplate(t: Template, chain: Chain): UiLeg[] {
  const strikes = chain.rows.map(r => r.strike)
  const atmIdx = strikes.reduce((best, s, i) => Math.abs(s - chain.atm) < Math.abs(strikes[best] - chain.atm) ? i : best, 0)
  const at = (off: number) => strikes[Math.max(0, Math.min(strikes.length - 1, atmIdx + off))]
  const opt = (side: Side, kind: 'CE' | 'PE', off: number) => {
    const k = at(off); const { premium, iv } = fromChain(chain, k, kind)
    return mk(side, kind, k, premium, iv)
  }
  switch (t) {
    case 'Long call':         return [opt('buy', 'CE', 0)]
    case 'Long put':          return [opt('buy', 'PE', 0)]
    case 'Bull call spread':  return [opt('buy', 'CE', 0), opt('sell', 'CE', 2)]
    case 'Bear put spread':   return [opt('buy', 'PE', 0), opt('sell', 'PE', -2)]
    case 'Straddle':          return [opt('buy', 'CE', 0), opt('buy', 'PE', 0)]
    case 'Strangle':          return [opt('buy', 'CE', 2), opt('buy', 'PE', -2)]
    case 'Iron condor':       return [opt('sell', 'PE', -2), opt('buy', 'PE', -4), opt('sell', 'CE', 2), opt('buy', 'CE', 4)]
    case 'Covered call (fut+CE)':
      return [mk('buy', 'FUT', null, chain.future ?? chain.forward ?? chain.spot, null), opt('sell', 'CE', 2)]
  }
}

// ── payoff chart (repo SVG pattern — no chart lib) ──────────────────────────────

function PayoffChart({ a, forward, lotNote }: { a: Analysis; forward: number; lotNote: string }) {
  const W = 680, H = 300, padL = 64, padR = 14, padT = 14, padB = 34
  const g = a.payoff
  const xs = g.map(p => p.s), ys = g.flatMap(p => [p.expiry, p.now])
  const xmin = xs[0], xmax = xs[xs.length - 1]
  let ymin = Math.min(...ys, 0), ymax = Math.max(...ys, 0)
  const span = (ymax - ymin) || 1; ymin -= span * 0.06; ymax += span * 0.06
  const x = (s: number) => padL + (s - xmin) / (xmax - xmin || 1) * (W - padL - padR)
  const y = (v: number) => padT + (ymax - v) / (ymax - ymin) * (H - padT - padB)
  // expiry curve split at its zero crossings (breakevens ARE grid points, so the cut is
  // exact for single-expiry books) → green above zero, red below
  const segs: { d: string; pos: boolean }[] = []
  let d = `M${x(g[0].s).toFixed(1)},${y(g[0].expiry).toFixed(1)}`
  let pos = (g[0].expiry !== 0 ? g[0].expiry : g[1]?.expiry ?? 0) >= 0
  for (let i = 1; i < g.length; i++) {
    d += `L${x(g[i].s).toFixed(1)},${y(g[i].expiry).toFixed(1)}`
    if (i < g.length - 1 && Math.abs(g[i].expiry) < 0.01) {   // breakeven grid point: cut here
      segs.push({ d, pos })
      d = `M${x(g[i].s).toFixed(1)},${y(g[i].expiry).toFixed(1)}`
      pos = g[i + 1].expiry >= 0
    }
  }
  segs.push({ d, pos })
  const nowPath = g.map((p, i) => `${i ? 'L' : 'M'}${x(p.s).toFixed(1)},${y(p.now).toFixed(1)}`).join('')
  const yTicks = useMemo(() => {
    const t: number[] = [], step = span / 4
    for (let v = Math.ceil(ymin / step) * step; v <= ymax; v += step) t.push(v)
    return t
  }, [ymin, ymax, span])
  const xTicks = useMemo(() => Array.from({ length: 6 }, (_, i) => xmin + (xmax - xmin) * i / 5), [xmin, xmax])
  const short = (v: number) => Math.abs(v) >= 1e5 ? `${(v / 1e5).toFixed(1)}L` : Math.abs(v) >= 1e3 ? `${(v / 1e3).toFixed(1)}k` : v.toFixed(0)
  return (
    <div>
      <svg viewBox={`0 0 ${W} ${H}`} style={{ width: '100%', height: 'auto', display: 'block' }} role="img"
           aria-label="Strategy payoff at expiry and today">
        {yTicks.map(v => (
          <g key={v}>
            <line x1={padL} x2={W - padR} y1={y(v)} y2={y(v)} stroke={T.border} strokeWidth={Math.abs(v) < 1e-9 ? 1.4 : 0.6} />
            <text x={padL - 6} y={y(v) + 3} fontSize={9.5} fill={T.dim} textAnchor="end" fontFamily={T.mono}>₹{short(v)}</text>
          </g>
        ))}
        {xTicks.map(s => (
          <text key={s} x={x(s)} y={H - padB + 14} fontSize={9.5} fill={T.dim} textAnchor="middle" fontFamily={T.mono}>{s.toFixed(0)}</text>
        ))}
        {/* forward */}
        <line x1={x(forward)} x2={x(forward)} y1={padT} y2={H - padB} stroke={T.amber} strokeDasharray="3 3" opacity={0.8} />
        <text x={x(forward) + 4} y={padT + 10} fontSize={9.5} fill={T.amber} fontFamily={T.mono}>fwd {forward.toFixed(0)}</text>
        {/* breakevens: labelled, exact */}
        {a.breakevens.map(b => (
          <g key={b}>
            <line x1={x(b)} x2={x(b)} y1={padT} y2={H - padB} stroke={T.cyan} strokeDasharray="5 4" opacity={0.75} />
            <text x={x(b)} y={H - padB - 4} fontSize={9.5} fill={T.cyan} textAnchor="middle" fontFamily={T.mono}>BE {b.toFixed(1)}</text>
          </g>
        ))}
        {/* value today (cyan) then expiry (green/red by sign) on top */}
        <path d={nowPath} fill="none" stroke={T.cyan} strokeWidth={1.3} opacity={0.85} />
        {segs.map((s, i) => <path key={i} d={s.d} fill="none" stroke={s.pos ? T.green : T.red} strokeWidth={2} />)}
      </svg>
      <div style={{ fontSize: 10.5, color: T.muted, marginTop: 4 }}>
        <span style={{ color: T.green }}>— P&L at expiry</span> (red where losing) ·{' '}
        <span style={{ color: T.cyan }}>— today (Black-76)</span> · <span style={{ color: T.cyan }}>┆ breakevens (exact)</span> · {lotNote}
      </div>
    </div>
  )
}

// ── main page ───────────────────────────────────────────────────────────────────

export function StrategyBuilder() {
  const [symbol, setSymbol] = useState('NIFTY')
  const [expiry, setExpiry] = useState<string | null>(null)
  const [chain, setChain] = useState<Chain | null>(null)
  const [underlyings, setUnderlyings] = useState<string[]>([])
  const [chainErr, setChainErr] = useState<unknown>(null)
  const [loading, setLoading] = useState(false)
  const [legs, setLegs] = useState<UiLeg[]>([])
  const [template, setTemplate] = useState<Template | null>('Straddle')
  const [analysis, setAnalysis] = useState<Analysis | null>(null)
  const [anErr, setAnErr] = useState<string | null>(null)
  const [busy, setBusy] = useState(false)

  const loadChain = useCallback(() => {
    setLoading(true); setChainErr(null)
    getOptionChain(symbol, expiry ?? undefined)
      .then(r => {
        setChain(r.data)
        if (r.data.underlyings?.length) setUnderlyings(r.data.underlyings)
      })
      .catch(e => { setChainErr(e?.response?.data?.detail ?? e?.message ?? 'chain unavailable'); setChain(null) })
      .finally(() => setLoading(false))
  }, [symbol, expiry])
  useEffect(() => { loadChain() }, [loadChain])

  // chain (re)loaded → re-seed the active template so strikes/premiums always match it
  useEffect(() => {
    if (!chain) return
    if (template) setLegs(seedTemplate(template, chain))
    else setLegs([])                                    // custom book: a new chain means new prices — start clean
  }, [chain])                                            // eslint-disable-line react-hooks/exhaustive-deps

  const lot = chain?.lot ?? 1
  const forward = chain?.forward ?? chain?.future ?? chain?.spot ?? null
  const strikes = useMemo(() => chain?.rows.map(r => r.strike) ?? [], [chain])

  // ── analyze (debounced) ──
  const timer = useRef<ReturnType<typeof setTimeout> | null>(null)
  useEffect(() => {
    if (!chain || forward == null || legs.length === 0) { setAnalysis(null); return }
    const bad = legs.find(l => (l.kind !== 'FUT' && l.strike == null) || !(Number(l.premium) >= 0) || !(Number(l.lots) >= 1))
    if (bad) { setAnErr('finish the highlighted leg (strike, premium ≥ 0, lots ≥ 1)'); return }
    setAnErr(null)
    if (timer.current) clearTimeout(timer.current)
    timer.current = setTimeout(() => {
      setBusy(true)
      axios.post<Analysis>('/api/options/strategy/analyze', {
        symbol,
        forward,
        days_to_expiry: Math.max(0, chain.days_to_expiry) + 0.5,
        default_iv: chain.atm_iv ?? 15,
        is_index: ['NIFTY', 'BANKNIFTY', 'FINNIFTY', 'MIDCPNIFTY', 'NIFTYNXT50'].includes(symbol.toUpperCase()),
        legs: legs.map(l => ({
          side: l.side, kind: l.kind, strike: l.kind === 'FUT' ? null : l.strike,
          premium: Number(l.premium) || 0, lots: Math.max(1, Math.round(Number(l.lots) || 1)),
          lot_size: lot, iv: Number(l.iv) > 0 ? Number(l.iv) : null,
        })),
      }, { timeout: 15000 })
        .then(r => { setAnalysis(r.data); setAnErr(null) })
        .catch(e => setAnErr(String(e?.response?.data?.detail ?? e?.message ?? 'analyze failed')))
        .finally(() => setBusy(false))
    }, 350)
    return () => { if (timer.current) clearTimeout(timer.current) }
  }, [legs, chain, forward, symbol, lot])

  // ── leg edits ──
  const edit = (id: number, patch: Partial<UiLeg>) => {
    setTemplate(null)
    setLegs(ls => ls.map(l => {
      if (l.id !== id) return l
      const next = { ...l, ...patch }
      // kind/strike changed → re-seed premium + IV from the chain
      if (chain && next.kind !== 'FUT' && (patch.kind || patch.strike !== undefined) && next.strike != null) {
        const { premium, iv } = fromChain(chain, next.strike, next.kind as 'CE' | 'PE')
        next.premium = premium != null ? String(premium) : next.premium
        next.iv = iv != null ? String(iv) : next.iv
      }
      if (patch.kind === 'FUT') { next.strike = null; next.premium = String(chain?.future ?? chain?.forward ?? chain?.spot ?? ''); next.iv = '' }
      if (patch.kind && patch.kind !== 'FUT' && l.kind === 'FUT' && chain) {
        const k = strikes.reduce((b, s) => Math.abs(s - chain.atm) < Math.abs(b - chain.atm) ? s : b, strikes[0])
        next.strike = k
        const { premium, iv } = fromChain(chain, k, patch.kind as 'CE' | 'PE')
        next.premium = premium != null ? String(premium) : ''; next.iv = iv != null ? String(iv) : ''
      }
      return next
    }))
  }
  const addLeg = () => {
    if (!chain || legs.length >= 4) return
    setTemplate(null)
    const k = strikes.reduce((b, s) => Math.abs(s - chain.atm) < Math.abs(b - chain.atm) ? s : b, strikes[0])
    const { premium, iv } = fromChain(chain, k, 'CE')
    setLegs(ls => [...ls, mk('buy', 'CE', k, premium, iv)])
  }
  const removeLeg = (id: number) => { setTemplate(null); setLegs(ls => ls.filter(l => l.id !== id)) }

  const net = analysis?.greeks.net
  const toggleStyle = (on: boolean, color: string) => ({
    fontFamily: T.mono, fontSize: 10, padding: '3px 7px', cursor: 'pointer', letterSpacing: 1,
    border: `1px solid ${on ? color : T.border}`, color: on ? T.bg : T.muted, background: on ? color : 'transparent',
  } as const)

  return (
    <div>
      <PageHeader code="OSTR" title="Options strategies"
        subtitle={chain ? `${chain.symbol} · NSE F&O bhavcopy ${chain.date} · expiry ${chain.expiry} (${chain.days_to_expiry}d) · lot ${chain.lot ?? '?'} · fwd ${n2(forward, 2)} (${chain.forward_source}) · ATM IV ${chain.atm_iv ?? '—'}%` : 'payoffs · Greeks · breakevens'}
        status={<Chip color={T.violet}>PRICES ONLY · NO ORDERS</Chip>}
        right={<div style={{ display: 'flex', gap: 8, alignItems: 'center' }}>
          <Select value={symbol} onChange={s => { setExpiry(null); setSymbol(s) }}
            options={[...new Set(['NIFTY', 'BANKNIFTY', 'FINNIFTY', ...underlyings])].map(u => ({ value: u, label: u }))} />
          <Btn size="sm" onClick={loadChain}>↻ CHAIN</Btn>
        </div>} />

      {loading && !chain && <Loading label={`option chain · ${symbol}`} />}
      {chainErr != null && <ErrorBox error={chainErr} onRetry={loadChain} />}

      {chain && (
        <>
          <div style={{ display: 'flex', gap: 6, flexWrap: 'wrap', marginBottom: 10, alignItems: 'center' }}>
            <Label>Expiry</Label>
            {chain.expiries.slice(0, 7).map(e => (
              <Chip key={e} color={T.cyan} active={e === chain.expiry} onClick={() => setExpiry(e)}>{e}</Chip>
            ))}
            <span style={{ flex: 1 }} />
            <Label>Templates</Label>
            {TEMPLATES.map(t => (
              <Chip key={t} color={T.amber} active={template === t}
                onClick={() => { setTemplate(t); setLegs(seedTemplate(t, chain)) }}>{t}</Chip>
            ))}
          </div>

          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(420px, 1fr))', gap: 12 }}>
            {/* ── left: legs ── */}
            <Panel title={`Legs (${legs.length}/4)`} subtitle={`lot ${lot} · premiums from the ${chain.date} chain, every field editable`}
              right={<Btn size="sm" onClick={addLeg} disabled={legs.length >= 4}>+ LEG</Btn>}>
              {legs.length === 0 && <Notice>Pick a template above or add a leg — up to four.</Notice>}
              <div style={{ display: 'grid', gap: 8 }}>
                {legs.map((l, i) => {
                  const incomplete = (l.kind !== 'FUT' && l.strike == null) || !(Number(l.premium) >= 0)
                  const pl = analysis?.greeks.per_leg[i]
                  return (
                    <div key={l.id} style={{ border: `1px solid ${incomplete ? T.red : T.border}`, padding: '8px 10px',
                                             display: 'flex', flexWrap: 'wrap', gap: 8, alignItems: 'flex-end', background: T.panel2 }}>
                      <div style={{ display: 'grid', gap: 4 }}>
                        <Label>Side</Label>
                        <div style={{ display: 'flex' }}>
                          <button style={toggleStyle(l.side === 'buy', T.green)} onClick={() => edit(l.id, { side: 'buy' })}>BUY</button>
                          <button style={toggleStyle(l.side === 'sell', T.red)} onClick={() => edit(l.id, { side: 'sell' })}>SELL</button>
                        </div>
                      </div>
                      <div style={{ display: 'grid', gap: 4 }}>
                        <Label>Type</Label>
                        <div style={{ display: 'flex' }}>
                          {(['CE', 'PE', 'FUT'] as Kind[]).map(k => (
                            <button key={k} style={toggleStyle(l.kind === k, T.amber)} onClick={() => edit(l.id, { kind: k })}>{k}</button>
                          ))}
                        </div>
                      </div>
                      {l.kind !== 'FUT' && (
                        <Select label="Strike" value={String(l.strike ?? '')} onChange={v => edit(l.id, { strike: Number(v) })}
                          options={strikes.map(s => ({ value: String(s), label: String(s) }))} />
                      )}
                      <Input label={l.kind === 'FUT' ? 'Entry price' : 'Premium ₹'} value={l.premium} width={84}
                        onChange={v => edit(l.id, { premium: v })} aria-label={`leg ${i + 1} premium`} />
                      {l.kind !== 'FUT' &&
                        <Input label="IV %" value={l.iv} width={56} onChange={v => edit(l.id, { iv: v })} aria-label={`leg ${i + 1} iv`} />}
                      <Input label="Lots" value={l.lots} width={48} onChange={v => edit(l.id, { lots: v })} aria-label={`leg ${i + 1} lots`} />
                      {pl && (
                        <span style={{ fontFamily: T.mono, fontSize: 10, color: T.muted, lineHeight: 1.7 }}>
                          Δ {n2(pl.delta as number, 1)} · θ {fmtInr(pl.theta_day as number, 0)}/d<br />
                          ν {fmtInr(pl.vega as number, 0)}{pl.price != null && <> · model ₹{n2(pl.price as number)}</>}
                        </span>
                      )}
                      <span style={{ flex: 1 }} />
                      <Btn size="sm" variant="danger" onClick={() => removeLeg(l.id)} title="remove leg">✕</Btn>
                    </div>
                  )
                })}
              </div>

              {analysis && (
                <div style={{ marginTop: 12, display: 'grid', gap: 10 }}>
                  <div style={{ display: 'flex', gap: 6, flexWrap: 'wrap' }}>
                    <Chip color={analysis.net_label === 'CREDIT' ? T.green : T.red}>
                      NET {analysis.net_label} {fmtInr(Math.abs(analysis.entry_cashflow), 0)}
                    </Chip>
                    {analysis.breakevens.map(b => <Chip key={b} color={T.cyan}>BE {n2(b, 1)}</Chip>)}
                    <Chip color={T.green}>
                      MAX PROFIT {analysis.max_profit.unbounded ? 'UNLIMITED ↑' : fmtInr(analysis.max_profit.value, 0)}
                    </Chip>
                    <Chip color={T.red}>
                      MAX LOSS {analysis.max_loss.unbounded ? 'UNLIMITED (upside)' : fmtInr(analysis.max_loss.value, 0)}
                    </Chip>
                  </div>
                  <Panel title="Margin & costs — ESTIMATE" accent={T.violet} pad={10}>
                    <div style={{ fontFamily: T.mono, fontSize: 11, display: 'grid', gap: 3 }}>
                      <div>Margin est. <span style={{ color: T.amber }}>{fmtInr(analysis.margin.total, 0)}</span>
                        {analysis.margin.premium_outflow > 0 && <span style={{ color: T.muted }}> (incl. {fmtInr(analysis.margin.premium_outflow, 0)} premium paid)</span>}
                        {analysis.margin.defined_risk_floor != null &&
                          <span style={{ color: T.muted }}> · defined-risk floor {fmtInr(analysis.margin.defined_risk_floor, 0)}</span>}
                      </div>
                      <div>Costs est. round trip <span style={{ color: T.amber }}>{fmtInr(analysis.costs.round_trip.total, 0)}</span>
                        <span style={{ color: T.muted }}> — brokerage {fmtInr(analysis.costs.round_trip.brokerage, 0)} ·
                          STT {fmtInr(analysis.costs.round_trip.stt, 0)} · txn {fmtInr(analysis.costs.round_trip.txn, 0)} ·
                          GST {fmtInr(analysis.costs.round_trip.gst, 0)}</span></div>
                      <div style={{ color: T.dim, fontSize: 10, lineHeight: 1.5 }}>{analysis.margin.note}</div>
                      <div style={{ color: T.dim, fontSize: 10, lineHeight: 1.5 }}>{analysis.costs.note}</div>
                    </div>
                  </Panel>
                </div>
              )}
            </Panel>

            {/* ── right: payoff + Greeks ── */}
            <Panel title="Payoff" accent={T.green}
              subtitle={busy ? 'pricing…' : analysis ? `to scale · ${analysis.single_expiry ? 'at expiry + today' : 'at NEAREST expiry (calendar) + today'}` : undefined}>
              {anErr && <ErrorBox error={anErr} />}
              {!analysis && !anErr && legs.length > 0 && <Loading label="pricing" />}
              {!analysis && legs.length === 0 && <Notice>The payoff draws here once the book has a leg.</Notice>}
              {analysis && forward != null && (
                <>
                  <PayoffChart a={analysis} forward={forward} lotNote={`lot ${lot} · ${chain.expiry}`} />
                  {net && (
                    <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(118px, 1fr))', gap: 8, marginTop: 12 }}>
                      <Stat big={false} label="Net delta" value={n2(net.delta, 1)} accent={T.amber}
                        sub={`≈ ${fmtInr(net.delta * forward, 0)} of ${chain.symbol}`} color={net.delta >= 0 ? T.green : T.red} />
                      <Stat big={false} label="Gamma" value={n2(net.gamma, 4)} sub="Δ change / ₹1 move" />
                      <Stat big={false} label="Theta / day" value={fmtInr(net.theta_day, 0)}
                        color={net.theta_day >= 0 ? T.green : T.red} sub="₹ per calendar day" />
                      <Stat big={false} label="Vega" value={fmtInr(net.vega, 0)} sub="₹ per IV point"
                        color={net.vega >= 0 ? T.green : T.red} />
                      <Stat big={false} label="Rho" value={fmtInr(net.rho, 0)} sub="₹ per +1% rate" />
                    </div>
                  )}
                  <div style={{ fontSize: 10, color: T.dim, marginTop: 8, lineHeight: 1.5 }}>{analysis.greeks.note}</div>
                </>
              )}
            </Panel>
          </div>
        </>
      )}
    </div>
  )
}
