'use client'

/**
 * Trade ticket — before you buy: shares for an amount, ICICI's real round-trip charges (itemised), the move you need
 * just to break even, an ATR stop with the rupee risk, and the tax on a +10 % gain. Arithmetic only; nothing is sent.
 */
import { useEffect, useState } from 'react'
import { getTradeTicket, type TradeTicket as Ticket } from '@/lib/api'
import { Input, T, fmtInr } from '@/components/terminal'

const inr = fmtInr
const KEY = 'suryadhana.ticket.v1'

export function TradeTicket({ price, atrPct }: { price: number; atrPct: number | null }) {
  const [amount, setAmount] = useState('50000')
  const [mult, setMult] = useState('2')
  const [capital, setCapital] = useState('500000')
  const [t, setT] = useState<Ticket | null>(null)
  useEffect(() => {
    try { const s = JSON.parse(localStorage.getItem(KEY) || '{}'); if (s.amount) setAmount(s.amount); if (s.mult) setMult(s.mult); if (s.capital) setCapital(s.capital) } catch { /* defaults */ }
  }, [])
  useEffect(() => {
    const value = Number(amount.replace(/[,₹\s]/g, '')), stop_atr = Number(mult), cap = Number(capital.replace(/[,₹\s]/g, ''))
    if (!(value > 0) || !(price > 0)) return
    try { localStorage.setItem(KEY, JSON.stringify({ amount, mult, capital })) } catch { /* private window */ }
    const id = setTimeout(() => {
      getTradeTicket({ value, price, atr_pct: atrPct, stop_atr: stop_atr > 0 ? stop_atr : 2, capital: cap > 0 ? cap : undefined })
        .then(r => setT(r.data)).catch(() => setT(null))
    }, 250)
    return () => clearTimeout(id)
  }, [amount, mult, capital, price, atrPct])

  const row = (k: string, v: React.ReactNode, c?: string) => (
    <div style={{ display: 'flex', justifyContent: 'space-between', padding: '3px 0', borderBottom: `1px solid ${T.border}`, fontSize: 11.5 }}>
      <span style={{ color: T.muted }}>{k}</span><span style={{ fontFamily: T.mono, color: c ?? T.text }}>{v}</span>
    </div>
  )
  return (
    <div>
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 70px 1fr', gap: 6, marginBottom: 8 }}>
        <Input label="Amount ₹" value={amount} onChange={setAmount} />
        <Input label="Stop ×ATR" value={mult} onChange={setMult} />
        <Input label="Your capital ₹" value={capital} onChange={setCapital} />
      </div>
      {!t ? <div style={{ fontSize: 11, color: T.dim }}>Enter an amount.</div> : <>
        {row('Shares', `${t.shares} × ${inr(t.price, 2)} = ${inr(t.notional)}`)}
        {row('Round trip (buy + sell)', <>{inr(t.round_trip.total, 0)} <span style={{ color: (t.round_trip_pct ?? 0) > 1 ? T.red : T.amber }}>({t.round_trip_pct?.toFixed(2)}%)</span></>)}
        <div style={{ fontSize: 10, color: T.dim, padding: '2px 0 4px' }}>
          brokerage {inr(t.round_trip.brokerage)} · STT {inr(t.round_trip.stt)} · GST {inr(t.round_trip.gst)} · DP {inr(t.round_trip.dp)} · stamp + exchange + SEBI {inr(t.round_trip.stamp + t.round_trip.exchange + t.round_trip.sebi + t.round_trip.ipft)}
        </div>
        {row('Breakeven move', `+${t.breakeven_move_pct?.toFixed(2)}%`, T.amber)}
        {t.stop && row(`Stop (${t.stop.atr_multiple}×ATR, −${t.stop.distance_pct}%)`, inr(t.stop.price, 2), T.red)}
        {t.stop && row('Loss if the stop is hit', <>{inr(t.stop.loss_if_hit)}{t.stop.loss_pct_of_capital != null && <span style={{ color: t.stop.loss_pct_of_capital > 1 ? T.red : T.muted }}> · {t.stop.loss_pct_of_capital}% of capital</span>}</>)}
        {row('Tax on a +10% gain', <>{inr(t.tax_on_10pct_gain.short_term)} <span style={{ color: T.dim }}>if sold within 1 yr · {inr(t.tax_on_10pct_gain.long_term_with_exemption)} after</span></>)}
        <div style={{ fontSize: 10, color: T.dim, marginTop: 6, lineHeight: 1.5 }}>
          {t.profile} · positions under {inr(t.min_position_for_1pct)} cost more than 1% round trip · intraday would cost {inr(t.intraday_round_trip.total)} · nothing is sent to the broker
        </div>
      </>}
    </div>
  )
}
