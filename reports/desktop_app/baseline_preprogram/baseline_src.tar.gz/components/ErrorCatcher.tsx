'use client'

/**
 * ErrorCatcher — Catches window.onerror + unhandledrejection and renders
 * the error prominently in the top-right corner.
 *
 * This is a DIAGNOSTIC TOOL. Remove once the root cause is identified.
 *
 * Rationale: global-error.tsx only catches React render-phase errors.
 * useEffect async errors become unhandled exceptions that only show in the
 * browser console. This component makes them visible on the page itself.
 */

import { Z } from '@/lib/z'
import { useEffect, useState } from 'react'

interface CaughtError {
  message: string
  stack?: string
  source: 'onerror' | 'rejection'
}

export function ErrorCatcher() {
  const [errors, setErrors] = useState<CaughtError[]>([])

  useEffect(() => {
    const pushErr = (err: CaughtError) => {
      setErrors(prev => [...prev.slice(-4), err]) // keep last 5
    }

    const handleError = (event: ErrorEvent) => {
      pushErr({
        message: event.message || 'Unknown error',
        stack: event.error?.stack,
        source: 'onerror',
      })
    }

    const handleRejection = (event: PromiseRejectionEvent) => {
      const reason = event.reason
      const message =
        typeof reason === 'string'
          ? reason
          : reason?.message || String(reason) || 'Unhandled Promise rejection'
      pushErr({
        message,
        stack: reason?.stack,
        source: 'rejection',
      })
    }

    window.addEventListener('error', handleError)
    window.addEventListener('unhandledrejection', handleRejection)

    return () => {
      window.removeEventListener('error', handleError)
      window.removeEventListener('unhandledrejection', handleRejection)
    }
  }, [])

  if (errors.length === 0) return null

  return (
    <div
      style={{
        position: 'fixed',
        top: 12,
        left: '50%',
        transform: 'translateX(-50%)',
        zIndex: Z.toast,
        background: '#0D0609',
        border: '1px solid #ff4d5e',
        borderRadius: 8,
        padding: '16px 20px',
        maxWidth: 680,
        width: 'calc(100vw - 32px)',
        boxShadow: '0 0 40px rgba(255,59,71,0.25)',
        fontFamily: "'JetBrains Mono', 'Courier New', monospace",
      }}
    >
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 12 }}>
        <span style={{ color: '#ff4d5e', fontWeight: 700, fontSize: 11, letterSpacing: 2, textTransform: 'uppercase' }}>
          ⚠ Uncaught Client Exception ({errors.length})
        </span>
        <button
          onClick={() => setErrors([])}
          style={{
            background: 'rgba(255,59,71,0.1)',
            border: '1px solid rgba(255,59,71,0.3)',
            color: '#ff4d5e',
            borderRadius: 4,
            padding: '2px 8px',
            cursor: 'pointer',
            fontSize: 11,
            fontFamily: 'inherit',
          }}
        >
          Dismiss
        </button>
      </div>
      {errors.map((e, i) => (
        <div
          key={i}
          style={{
            borderTop: i > 0 ? '1px solid rgba(255,59,71,0.2)' : 'none',
            paddingTop: i > 0 ? 12 : 0,
            marginTop: i > 0 ? 12 : 0,
          }}
        >
          <p style={{ color: '#ffb000', fontWeight: 600, fontSize: 12, marginBottom: 6 }}>
            [{e.source.toUpperCase()}] {e.message}
          </p>
          {e.stack && (
            <pre
              style={{
                color: '#aab3c2',
                fontSize: 10,
                whiteSpace: 'pre-wrap',
                wordBreak: 'break-all',
                maxHeight: 200,
                overflowY: 'auto',
                margin: 0,
                lineHeight: 1.5,
              }}
            >
              {e.stack}
            </pre>
          )}
        </div>
      ))}
    </div>
  )
}
