'use client'

import { apiError } from '@/lib/errors'
/**
 * Gold desk accuracy log — the 08:45 IST fair open against the actual MCX open, day by day.
 * Answers: is the model better than "open = yesterday's settlement", and is the ₹300 chase limit the right size?
 * Rows are written by master-controller (snapshot 08:45, ICICI open 09:10); without an ICICI session, type the open here.
 */
import { useCallback, useEffect, useState } from 'react'
import { getGoldLog, setGoldActual, type GoldLogRow, type GoldLogStats } from '@/lib/api'
import { Btn, DataTable, Input, Panel, Stat, T, type Column, fmtInr } from '@/components/terminal'

const inr = (v?: number | null) => fmtInr(v)
const signed = (v?: number | null) => (v == null ? '—' : `${v > 0 ? '+' : v < 0 ? '−' : ''}₹${Math.abs(Math.round(v)).toLocaleString('en-IN')}`)

export function GoldAccuracyLog({ threshold }: { threshold: number }) {
  const [rows, setRows] = useState<GoldLogRow[]>([])
  const [stats, setStats] = useState<GoldLogStats>({ days: 0 })
  const [draft, setDraft] = useState<Record<string, string>>({})
  const [msg, setMsg] = useState<string | null>(null)

  const load = useCallback(() => {
    getGoldLog(threshold).then(r => { setRows(r.data.rows); setStats(r.data.stats) }).catch(() => {})
  }, [threshold])
  useEffect(() => { load() }, [load])

  const save = async (date: string) => {
    const v = Number((draft[date] ?? '').replace(/[,₹\s]/g, ''))
    if (!v) return
    try { await setGoldActual(date, v); setMsg(null); setDraft(d => ({ ...d, [date]: '' })); load() }
    catch (e: any) { setMsg(apiError(e, 'Could not save')) }
  }

  const cols: Column<GoldLogRow>[] = [
    { key: 'date', label: 'Day', render: r => new Date(`${r.date}T00:00:00`).toLocaleDateString('en-IN', { weekday: 'short', day: '2-digit', month: 'short' }) },
    { key: 'baseline', label: 'Settlement', align: 'right', render: r => <span style={{ color: T.muted }}>{inr(r.baseline)}</span> },
    { key: 'fair_open', label: 'Fair open 08:45', align: 'right', render: r => <span style={{ color: T.amber }}>{inr(r.fair_open)}</span> },
    { key: 'actual_open', label: 'Actual open', align: 'right', render: r => r.actual_open != null
      ? <span title={r.actual_source}>{inr(r.actual_open)}</span>
      : (
        <span style={{ display: 'inline-flex', gap: 4 }} onClick={e => e.stopPropagation()}>
          <Input value={draft[r.date] ?? ''} onChange={v => setDraft(d => ({ ...d, [r.date]: v }))} placeholder="type open" width={96} />
          <Btn size="sm" onClick={() => save(r.date)}>SAVE</Btn>
        </span>
      ) },
    { key: 'error', label: 'Model miss', align: 'right', sort: r => Math.abs(r.error ?? 0),
      render: r => <span style={{ color: r.error == null ? T.dim : Math.abs(r.error) <= threshold ? T.green : T.red, fontWeight: 600 }}>{signed(r.error)}</span> },
    { key: 'naive_error', label: 'Naive miss', align: 'right', render: r => <span style={{ color: T.muted }}>{signed(r.naive_error)}</span> },
  ]

  const better = stats.naive_mean_abs_error != null && stats.mean_abs_error != null
    ? stats.mean_abs_error < stats.naive_mean_abs_error : null
  return (
    <Panel title="Accuracy log" accent={T.green} pad={0}
      subtitle="fair open recorded 08:45 IST vs the actual MCX open · naive = open at yesterday's settlement"
      right={<Btn size="sm" onClick={load}>↻</Btn>}>
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, minmax(0, 1fr))', gap: 8, padding: 10 }}>
        <Stat big={false} label="Days measured" value={stats.days} sub={stats.days < 20 ? 'need ~20 to size the chase limit' : 'enough for a first read'} />
        <Stat big={false} label="Typical model miss" value={stats.days ? inr(stats.median_abs_error) : '—'}
          sub={stats.days ? `mean ${inr(stats.mean_abs_error)} · 90% within ${inr(stats.p90_abs_error)}` : 'median absolute error'} />
        <Stat big={false} label={`Within ₹${threshold}`} value={stats.days ? `${stats.within_threshold_pct}%` : '—'}
          color={(stats.within_threshold_pct ?? 0) >= 80 ? T.green : T.amber} sub={stats.days ? `bias ${signed(stats.bias)} (+ = opens above fair)` : 'share of days'} />
        <Stat big={false} label="Model vs naive" value={better == null ? '—' : better ? 'BETTER' : 'WORSE'}
          color={better == null ? T.muted : better ? T.green : T.red}
          sub={stats.naive_mean_abs_error != null ? `naive mean miss ${inr(stats.naive_mean_abs_error)}` : 'naive = settlement'} />
      </div>
      {msg && <div style={{ padding: '0 12px 8px', fontSize: 11, color: T.red }}>{msg}</div>}
      <DataTable columns={cols} rows={rows} rowKey={r => r.date} dense maxHeight={280}
        empty="First snapshot at 08:45 IST on the next trading day (master-controller). The open is filled from ICICI at 09:10, or type it here." />
    </Panel>
  )
}
