'use client'

/**
 * MCXG — MCX gold desk (worldclass program W4). Stands alone next to CMDT's pre-open desk:
 *   1. session clock  — OPEN/CLOSED with time-to-close, MCX's own 2026 holiday calendar
 *   2. live quote     — ICICI Breeze when the account can serve MCX, otherwise an HONEST
 *                       degrade with the two fallbacks that always work: the ICICI price-band
 *                       settlement and the COMEX × USD/INR fair value (each source-labeled)
 *   3. overlay        — COMEX GC last, USD/INR, landed + model fair value, premium/discount
 *   4. specs          — GOLD / GOLDM / GOLDPETAL / GOLDGUINEA: lot, tick value, delivery,
 *                       indicative margin, computed + observed expiries
 *   5. paper ticket   — lot-aware pricing (notional, margin, round-trip MCX costs). PAPER:
 *                       it prices the trade and records nothing.
 *
 * Data: /api/mcx/* (services/ui-api/routers/mcx.py; reference data shared/mcx_specs.py).
 */
import { useCallback, useEffect, useMemo, useRef, useState } from 'react'
import { Chip, DataTable, Input, Loading, Notice, PageHeader, Panel, Select, Stat, T,
         fmtInr, fmtNum, type Column } from '@/components/terminal'

const SESSION_MS = 30_000
const QUOTE_MS = 30_000
const OVERLAY_MS = 60_000

type ContractCode = 'GOLD' | 'GOLDM' | 'GOLDPETAL' | 'GOLDGUINEA'
const CODES: ContractCode[] = ['GOLD', 'GOLDM', 'GOLDPETAL', 'GOLDGUINEA']

interface SessionState {
  as_of: string; is_open: boolean; segment: 'morning' | 'evening' | null; weekend: boolean
  holiday: { name: string; closure: 'full' | 'morning' | 'evening' } | null
  opens_at: string; closes_at: string
  seconds_to_close: number | null; seconds_to_open: number | null
  note: string; calendar_warning?: string
  upcoming_holidays: { date: string; day: string; name: string; closure: string }[]
  special_sessions: { date: string; name: string; note: string }[]
  calendar_source: string
}
interface SpecRow {
  code: string; name: string; lot: string; quotation: string; tick_rupees: number; tick_value: number
  delivery_unit: string; purity: string; expiry_rule: string; cycle: string
  span_margin_pct_indicative: number; notes: string
  computed_expiries: string[]; observed_expiries: string[] | null
  front?: { expiry: string; settlement: number; band_low: number; band_high: number; open_interest_lots: number }
  indicative_margin_rupees?: number
}
interface SpecsPayload {
  as_of: string; contracts: SpecRow[]
  master: { available: boolean; published: string | null; source: string }
  margin_note: string; expiry_note: string
}
interface FairValue {
  comex: { symbol: string; price: number; as_of: string | null }
  usdinr: { symbol: string; price: number; as_of: string | null }
  landed: number; landed_note: string; source: string
  fair?: number; gap_vs_settlement?: number; implied_premium_pct?: number; settlement_session?: string
}
interface QuotePayload {
  as_of: string; contract: string; expiry: string; expiry_source: string
  tick_value: number; lot: string
  available: boolean; reason?: string; live_verify_pending?: boolean
  quote: { ltp: number | null; open: number | null; high: number | null; low: number | null
           previous_close: number | null; time: string | null; source: string } | null
  fallbacks: {
    band: { settlement: number; band_low: number; band_high: number; open_interest_lots: number; source: string } | null
    fair_value: FairValue | null
  }
  best: { price: number; source: string } | null
}
interface OverlayPayload {
  as_of: string; contract: string; expiry: string
  overlay: FairValue | null
  mcx_price: number | null
  premium: { vs: string; rupees: number; pct: number } | null
}
interface TicketPayload {
  paper: boolean; recorded: boolean; contract: string; lot: string; lots: number; price: number
  notional: number; tick_value_per_lot: number; tick_value_position: number
  indicative_margin: number; margin_pct_indicative: number
  round_trip: {
    turnover_per_side: number
    buy: CostLeg; sell: CostLeg; total: number
    pct_of_notional: number | null; breakeven_ticks: number | null; breakeven_price_move: number | null
    assumptions: string
  }
  note: string
}
interface CostLeg { brokerage: number; exchange_txn: number; sebi: number; stamp: number; ctt: number; gst: number; total: number }
type LegRow = CostLeg & { side: 'buy' | 'sell' }

async function getJson<T>(url: string, init?: RequestInit): Promise<T> {
  const r = await fetch(url, init)
  const body = await r.json().catch(() => null)
  if (!r.ok) {
    const msg = body?.error?.message ?? (typeof body?.detail === 'string' ? body.detail : null)
    throw new Error(msg ?? `HTTP ${r.status}`)
  }
  return body as T
}

const hms = (s: number | null): string => {
  if (s == null || s < 0) return '—'
  const h = Math.floor(s / 3600), m = Math.floor((s % 3600) / 60), sec = s % 60
  return h > 0 ? `${h}h ${m}m ${sec}s` : m > 0 ? `${m}m ${sec}s` : `${sec}s`
}
const istClock = (iso?: string | null) => iso
  ? new Date(iso).toLocaleString('en-IN', { timeZone: 'Asia/Kolkata', day: '2-digit', month: 'short', hour: '2-digit', minute: '2-digit', hour12: false })
  : '—'
const num = (s: string): number | undefined => {
  const v = Number(String(s).replace(/[,₹\s]/g, ''))
  return Number.isFinite(v) && v > 0 ? v : undefined
}

const CLOSURE_CHIP: Record<string, { label: string; color: string }> = {
  full: { label: 'FULL DAY', color: T.red },
  morning: { label: 'EVE ONLY (17:00→)', color: T.amber },
  evening: { label: 'MORNING ONLY (→17:00)', color: T.cyan },
}

export function McxGoldDesk() {
  const [session, setSession] = useState<SessionState | null>(null)
  const [specsP, setSpecsP] = useState<SpecsPayload | null>(null)
  const [quote, setQuote] = useState<QuotePayload | null>(null)
  const [overlay, setOverlay] = useState<OverlayPayload | null>(null)
  const [ticket, setTicket] = useState<TicketPayload | null>(null)
  const [err, setErr] = useState<string | null>(null)
  const [contract, setContract] = useState<ContractCode>('GOLD')
  const [expiry, setExpiry] = useState<string>('')          // '' = front by open interest
  const [lots, setLots] = useState('1')
  const [priceIn, setPriceIn] = useState('')                // '' = use the desk's best price
  const [brokerage, setBrokerage] = useState('20')
  const [countdown, setCountdown] = useState<number | null>(null)
  const quoteReq = useRef(0)

  // ── session clock (30 s poll + 1 s local tick) ─────────────────────────────────
  const loadSession = useCallback(async () => {
    try {
      const s = await getJson<SessionState>('/api/mcx/session')
      setSession(s)
      setCountdown(s.is_open ? s.seconds_to_close : s.seconds_to_open)
      setErr(null)
    } catch (e: any) { setErr(e?.message ?? 'MCX desk unavailable') }
  }, [])
  useEffect(() => {
    loadSession()
    const iv = setInterval(loadSession, SESSION_MS)
    return () => clearInterval(iv)
  }, [loadSession])
  useEffect(() => {
    const t = setInterval(() => setCountdown(c => (c == null ? c : Math.max(0, c - 1))), 1000)
    return () => clearInterval(t)
  }, [])

  // ── specs (5 min) ──────────────────────────────────────────────────────────────
  useEffect(() => {
    let alive = true
    const load = () => getJson<SpecsPayload>('/api/mcx/specs').then(p => { if (alive) setSpecsP(p) }).catch(() => {})
    load()
    const iv = setInterval(load, 300_000)
    return () => { alive = false; clearInterval(iv) }
  }, [])

  // ── quote (30 s, per contract+expiry) ──────────────────────────────────────────
  const loadQuote = useCallback(async () => {
    const id = ++quoteReq.current
    try {
      const q = await getJson<QuotePayload>(
        `/api/mcx/quote?contract=${contract}${expiry ? `&expiry=${expiry}` : ''}`)
      if (id === quoteReq.current) setQuote(q)
    } catch { /* the session/specs panels still stand */ }
  }, [contract, expiry])
  useEffect(() => {
    setQuote(null)
    loadQuote()
    const iv = setInterval(loadQuote, QUOTE_MS)
    return () => clearInterval(iv)
  }, [loadQuote])

  // ── overlay (60 s; premium only against a LIVE broker price, never circular) ───
  useEffect(() => {
    let alive = true
    const live = quote?.available && quote.quote?.ltp ? `&mcx_price=${quote.quote.ltp}` : ''
    const load = () =>
      getJson<OverlayPayload>(`/api/mcx/overlay?contract=${contract}${expiry ? `&expiry=${expiry}` : ''}${live}`)
        .then(p => { if (alive) setOverlay(p) }).catch(() => {})
    load()
    const iv = setInterval(load, OVERLAY_MS)
    return () => { alive = false; clearInterval(iv) }
  }, [contract, expiry, quote?.available, quote?.quote?.ltp])

  // ── paper ticket (debounced POST; prices only, records nothing) ────────────────
  const ticketPrice = num(priceIn) ?? quote?.best?.price
  useEffect(() => {
    const lotsN = Math.max(1, Math.floor(num(lots) ?? 1))
    if (!ticketPrice) { setTicket(null); return }
    let alive = true
    const t = setTimeout(() => {
      getJson<TicketPayload>('/api/mcx/ticket', {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ contract, lots: lotsN, price: ticketPrice,
                               brokerage_per_order: num(brokerage) ?? 20 }),
      }).then(p => { if (alive) setTicket(p) }).catch(() => { if (alive) setTicket(null) })
    }, 400)
    return () => { alive = false; clearTimeout(t) }
  }, [contract, lots, ticketPrice, brokerage])

  const spec = useMemo(() => specsP?.contracts.find(c => c.code === contract) ?? null, [specsP, contract])
  const expiryOptions = useMemo(() => {
    const xs = spec?.observed_expiries ?? spec?.computed_expiries ?? []
    return [{ value: '', label: 'front (by OI)' }, ...xs.map(x => ({ value: x, label: x }))]
  }, [spec])
  const fv = quote?.fallbacks.fair_value ?? overlay?.overlay ?? null
  const stateColor = session ? (session.is_open ? T.green : T.red) : T.muted
  const holidayRows = session?.upcoming_holidays ?? []

  const holCols: Column<SessionState['upcoming_holidays'][number]>[] = [
    { key: 'date', label: 'Date', render: r => <span style={{ color: T.text }}>{r.date} <span style={{ color: T.dim }}>{r.day}</span></span> },
    { key: 'name', label: 'MCX holiday', render: r => <span style={{ color: T.text }}>{r.name}</span> },
    { key: 'closure', label: 'Closure', align: 'right', render: r => {
        const c = CLOSURE_CHIP[r.closure] ?? { label: r.closure.toUpperCase(), color: T.muted }
        return <Chip color={c.color}>{c.label}</Chip>
      } },
  ]
  const specCols: Column<SpecRow>[] = [
    { key: 'code', label: 'Contract', render: r => <span style={{ color: r.code === contract ? T.amber : T.text, fontWeight: 600 }}>{r.code}<div style={{ color: T.dim, fontSize: 9 }}>{r.name}</div></span> },
    { key: 'lot', label: 'Lot', align: 'right', render: r => <span style={{ color: T.bright }}>{r.lot}</span> },
    { key: 'quotation', label: 'Quote', align: 'right', render: r => <span style={{ color: T.muted }}>{r.quotation}</span> },
    { key: 'tick_value', label: 'Tick', align: 'right', sort: r => r.tick_value,
      render: r => <span style={{ color: T.bright }}>₹{fmtNum(r.tick_rupees)} = {fmtInr(r.tick_value)}</span> },
    { key: 'delivery_unit', label: 'Delivery', align: 'right', render: r => <span style={{ color: T.muted }}>{r.delivery_unit} <span style={{ color: T.dim }}>({r.purity})</span></span> },
    { key: 'span_margin_pct_indicative', label: 'Margin*', align: 'right',
      render: r => <span style={{ color: T.amber }}>{r.span_margin_pct_indicative}%{r.indicative_margin_rupees ? <div style={{ color: T.dim, fontSize: 9 }}>≈{fmtInr(r.indicative_margin_rupees)}/lot</div> : null}</span> },
    { key: 'cycle', label: 'Cycle', align: 'right', render: r => <span style={{ color: T.muted }}>{r.cycle}</span> },
    { key: 'expiries', label: 'Next expiries', align: 'right', render: r => (
        <span style={{ color: T.text }}>
          {(r.observed_expiries ?? r.computed_expiries).slice(0, 2).join(' · ')}
          <div style={{ color: r.observed_expiries ? T.green : T.dim, fontSize: 9 }}>
            {r.observed_expiries ? 'observed (ICICI master)' : 'computed (rule)'}
          </div>
        </span>
      ) },
  ]

  const legRows: LegRow[] = ticket ? (['buy', 'sell'] as const).map(side => ({ side, ...ticket.round_trip[side] })) : []
  const legCols: Column<LegRow>[] = [
    { key: 'side', label: 'Leg', render: r => <span style={{ color: r.side === 'buy' ? T.green : T.red, fontWeight: 600 }}>{r.side.toUpperCase()}</span> },
    { key: 'brokerage', label: 'Brokerage', align: 'right', render: r => <span style={{ color: T.text }}>{fmtInr(r.brokerage, 2)}</span> },
    { key: 'exchange_txn', label: 'Exch 0.0021%', align: 'right', render: r => <span style={{ color: T.text }}>{fmtInr(r.exchange_txn, 2)}</span> },
    { key: 'ctt', label: 'CTT 0.01% (sell)', align: 'right', render: r => <span style={{ color: r.ctt ? T.amber : T.dim }}>{fmtInr(r.ctt, 2)}</span> },
    { key: 'stamp', label: 'Stamp (buy)', align: 'right', render: r => <span style={{ color: r.stamp ? T.text : T.dim }}>{fmtInr(r.stamp, 2)}</span> },
    { key: 'sebi', label: 'SEBI', align: 'right', render: r => <span style={{ color: T.text }}>{fmtInr(r.sebi, 2)}</span> },
    { key: 'gst', label: 'GST 18%', align: 'right', render: r => <span style={{ color: T.text }}>{fmtInr(r.gst, 2)}</span> },
    { key: 'total', label: 'Total', align: 'right', render: r => <span style={{ color: T.bright, fontWeight: 700 }}>{fmtInr(r.total, 2)}</span> },
  ]

  return (
    <div>
      <PageHeader code="MCXG" title="MCX gold desk"
        subtitle="session clock · live quotes (degrade-honest) · contract specs · COMEX overlay · paper ticket"
        right={session && (
          <span style={{ display: 'inline-flex', gap: 10, alignItems: 'center' }}>
            <Chip color={stateColor}>{session.is_open ? `● OPEN · ${session.segment?.toUpperCase()}` : '■ CLOSED'}</Chip>
            <span style={{ fontFamily: T.mono, fontSize: 11, color: stateColor }}>
              {session.is_open ? `closes in ${hms(countdown)}` : `opens in ${hms(countdown)}`}
            </span>
          </span>
        )} />

      {err && <Notice color={T.red}>MCX desk unavailable: {err}</Notice>}
      {!session && !err && <Loading label="Reading the MCX session clock" />}

      {session && (
        <div style={{ display: 'grid', gap: 12 }}>
          {/* 1. session + calendar */}
          <div style={{ display: 'grid', gap: 12, gridTemplateColumns: 'minmax(0, 1.3fr) minmax(300px, 1fr)' }}>
            <Panel title="Session" accent={stateColor}
              subtitle={`Mon–Fri 09:00 → ${session.closes_at.includes('23:55') ? '23:55' : '23:30'} IST · as of ${istClock(session.as_of)}`}
              bodyStyle={{ display: 'grid', gap: 10 }}>
              <div style={{ display: 'grid', gap: 10, gridTemplateColumns: 'repeat(auto-fit, minmax(160px, 1fr))' }}>
                <Stat label="State" value={session.is_open ? 'OPEN' : 'CLOSED'} color={stateColor} accent={stateColor}
                  sub={session.holiday ? `${session.holiday.name} (${session.holiday.closure} closure)` : session.weekend ? 'weekend' : session.segment ? `${session.segment} session` : undefined} />
                <Stat label={session.is_open ? 'Closes' : 'Opens'} value={istClock(session.is_open ? session.closes_at : session.opens_at)}
                  accent={T.cyan} sub={session.is_open ? `in ${hms(countdown)}` : `in ${hms(countdown)}`} />
                <Stat label="Evening close" value={session.closes_at.includes('23:55') ? '23:55 IST' : '23:30 IST'}
                  accent={T.violet} sub="US-linked: 23:30 in NY summer, 23:55 in winter" />
              </div>
              {session.calendar_warning && <Notice color={T.amber}>{session.calendar_warning}</Notice>}
              <div style={{ fontSize: 10, color: T.dim, lineHeight: 1.5 }}>{session.note}</div>
            </Panel>
            <Panel title="MCX holidays ahead" subtitle="MCX's own calendar — not NSE's" accent={T.amber} pad={0}>
              <DataTable columns={holCols} rows={holidayRows} rowKey={r => r.date} dense
                empty="No MCX holidays left in the 2026 table" />
              {(session.special_sessions ?? []).map(s => (
                <div key={s.date} style={{ padding: '6px 12px', fontSize: 10, color: T.muted, borderTop: `1px solid ${T.border}` }}>
                  ◆ {s.date}: <span style={{ color: T.amber }}>{s.name}</span> — {s.note}
                </div>
              ))}
            </Panel>
          </div>

          {/* 2. quote + 3. overlay */}
          <div style={{ display: 'grid', gap: 12, gridTemplateColumns: 'minmax(0, 1.3fr) minmax(300px, 1fr)' }}>
            <Panel title="Quote" accent={quote?.available ? T.green : T.amber}
              subtitle={quote ? `${quote.contract} ${quote.expiry} (${quote.expiry_source}) · lot ${quote.lot} · tick ${fmtInr(quote.tick_value)}` : 'resolving the front contract'}
              right={
                <span style={{ display: 'inline-flex', gap: 8 }}>
                  <Select value={contract} onChange={v => { setContract(v); setExpiry('') }}
                    options={CODES.map(c => ({ value: c, label: c }))} />
                  <Select value={expiry} onChange={setExpiry} options={expiryOptions} />
                </span>
              }
              bodyStyle={{ display: 'grid', gap: 10 }}>
              {!quote && <Loading label="Asking the broker, the price band and the model" />}
              {quote?.available && quote.quote && (
                <div style={{ display: 'grid', gap: 10, gridTemplateColumns: 'repeat(auto-fit, minmax(140px, 1fr))' }}>
                  <Stat label={`LTP · ${quote.quote.source}`} value={fmtInr(quote.quote.ltp)} color={T.green} accent={T.green}
                    sub={quote.quote.time ?? undefined} />
                  <Stat label="Open" value={fmtInr(quote.quote.open)} accent={T.cyan} />
                  <Stat label="High / Low" value={`${fmtInr(quote.quote.high)} / ${fmtInr(quote.quote.low)}`} accent={T.violet} />
                  <Stat label="Prev close" value={fmtInr(quote.quote.previous_close)} accent={T.border} />
                </div>
              )}
              {quote && !quote.available && (
                <>
                  <Notice color={T.amber}>
                    <b>Broker quote unavailable</b> — {quote.reason ?? 'not served'}{' '}
                    {quote.live_verify_pending && <Chip color={T.violet}>LIVE-VERIFY PENDING · after the 08:00 login</Chip>}
                  </Notice>
                  <div style={{ display: 'grid', gap: 10, gridTemplateColumns: 'repeat(auto-fit, minmax(190px, 1fr))' }}>
                    <Stat label="Prev settlement · price band" value={fmtInr(quote.fallbacks.band?.settlement)}
                      accent={T.cyan}
                      sub={quote.fallbacks.band ? `band ${fmtInr(quote.fallbacks.band.band_low)}–${fmtInr(quote.fallbacks.band.band_high)} · OI ${fmtNum(quote.fallbacks.band.open_interest_lots)} lots` : 'ICICI master unavailable'} />
                    <Stat label="Fair value · COMEX×INR model" value={fmtInr(fv?.fair ?? fv?.landed)}
                      color={T.amber} accent={T.amber}
                      sub={fv?.fair ? `vs settlement ${fv.gap_vs_settlement != null && fv.gap_vs_settlement >= 0 ? '+' : ''}${fmtInr(fv?.gap_vs_settlement)}` : fv?.landed_note} />
                    {quote.best && <Stat label="Desk price in use" value={fmtInr(quote.best.price)} accent={T.green}
                      sub={quote.best.source} />}
                  </div>
                </>
              )}
            </Panel>

            <Panel title="COMEX × rupee overlay" accent={T.violet}
              subtitle={fv ? `GC ${fv.comex.symbol.replace('.CMX', '')} · updated ${istClock(overlay?.as_of)}` : 'Yahoo feed'}
              bodyStyle={{ display: 'grid', gap: 10 }}>
              {!fv && <Loading label="COMEX and USD/INR from Yahoo" />}
              {fv && (
                <>
                  <div style={{ display: 'grid', gap: 10, gridTemplateColumns: '1fr 1fr' }}>
                    <Stat label="COMEX gold" value={`$${fmtNum(fv.comex.price, 1)}`} accent={T.amber} sub={fv.comex.symbol} />
                    <Stat label="USD / INR" value={fmtNum(fv.usdinr.price, 2)} accent={T.cyan} sub="offshore before 09:00" />
                    <Stat label="Landed (no duty)" value={fmtInr(fv.landed)} accent={T.border} sub={fv.landed_note} />
                    <Stat label="Fair value (model)" value={fmtInr(fv.fair)} color={T.amber} accent={T.amber}
                      sub={fv.implied_premium_pct != null ? `MCX premium ≈ ${fmtNum(fv.implied_premium_pct, 1)}% over landed` : 'needs the settlement baseline'} />
                  </div>
                  {overlay?.premium
                    ? <Notice color={Math.abs(overlay.premium.rupees) <= 300 ? T.green : T.red}>
                        MCX live is {fmtInr(Math.abs(overlay.premium.rupees))} {overlay.premium.rupees >= 0 ? 'ABOVE' : 'BELOW'} {overlay.premium.vs} ({overlay.premium.pct > 0 ? '+' : ''}{fmtNum(overlay.premium.pct, 2)}%)
                      </Notice>
                    : <div style={{ fontSize: 10, color: T.dim }}>Premium vs fair appears when a live broker quote exists — never computed against the model itself.</div>}
                </>
              )}
            </Panel>
          </div>

          {/* 4. specs */}
          <Panel title="Contract specs — MCX gold family" accent={T.cyan} pad={0}
            subtitle={specsP ? (specsP.master.available ? `expiries cross-checked vs ICICI master (${specsP.master.published})` : 'ICICI master unavailable — computed expiries only') : undefined}>
            <DataTable columns={specCols} rows={specsP?.contracts ?? []} rowKey={r => r.code} dense
              empty="Specs unavailable" onRowClick={r => { setContract(r.code as ContractCode); setExpiry('') }} />
            <div style={{ padding: '6px 12px', fontSize: 10, color: T.dim, lineHeight: 1.6, borderTop: `1px solid ${T.border}` }}>
              *{specsP?.margin_note ?? 'Margins are indicative.'}<br />{specsP?.expiry_note}
            </div>
          </Panel>

          {/* 5. paper ticket */}
          <Panel title="Paper gold ticket" accent={T.green}
            subtitle="prices the trade — PAPER, records nothing, no order API exists on this desk"
            bodyStyle={{ display: 'grid', gap: 12 }}>
            <div style={{ display: 'grid', gap: 10, gridTemplateColumns: 'repeat(auto-fit, minmax(150px, 1fr))', alignItems: 'end' }}>
              <Select label="Contract" value={contract} onChange={v => { setContract(v); setExpiry('') }}
                options={CODES.map(c => ({ value: c, label: `${c} (${specsP?.contracts.find(x => x.code === c)?.lot ?? ''})` }))} />
              <Input label="Lots" value={lots} onChange={setLots} />
              <Input label="Price (₹, blank = desk price)" value={priceIn} onChange={setPriceIn}
                placeholder={quote?.best ? `${quote.best.price} · ${quote.best.source}` : 'no price source yet'} />
              <Input label="Brokerage / order (₹)" value={brokerage} onChange={setBrokerage} />
            </div>
            {!ticket && <div style={{ fontSize: 11, color: T.muted }}>Enter a price (or wait for a desk price) to size the trade.</div>}
            {ticket && (
              <>
                <div style={{ display: 'grid', gap: 10, gridTemplateColumns: 'repeat(auto-fit, minmax(160px, 1fr))' }}>
                  <Stat label="Notional" value={fmtInr(ticket.notional)} accent={T.cyan}
                    sub={`${ticket.lots} × ${ticket.lot} @ ${fmtInr(ticket.price)}`} />
                  <Stat label="Indicative margin*" value={fmtInr(ticket.indicative_margin)} color={T.amber} accent={T.amber}
                    sub={`${ticket.margin_pct_indicative}% SPAN+exposure — exchange revises daily`} />
                  <Stat label="Tick value" value={fmtInr(ticket.tick_value_position)} accent={T.violet}
                    sub={`${fmtInr(ticket.tick_value_per_lot)} per lot`} />
                  <Stat label="Round-trip cost" value={fmtInr(ticket.round_trip.total, 2)} accent={T.red} color={T.red}
                    sub={`${fmtNum(ticket.round_trip.pct_of_notional, 4)}% of notional · breakeven ${fmtNum(ticket.round_trip.breakeven_ticks, 1)} ticks (₹${fmtNum(ticket.round_trip.breakeven_price_move, 1)})`} />
                </div>
                <DataTable columns={legCols} rows={legRows} rowKey={r => r.side} dense empty="" />
                <div style={{ fontSize: 10, color: T.dim, lineHeight: 1.6 }}>
                  {ticket.note} Rates: exchange txn ₹2.10/lakh (0.0021%), CTT 0.01% sell side (squared-off futures),
                  SEBI ₹10/crore, stamp 0.002% buy side, GST 18% on brokerage+txn+SEBI — indicative, see shared/mcx_specs.py for citations.
                </div>
              </>
            )}
          </Panel>
        </div>
      )}
    </div>
  )
}

export default McxGoldDesk
