'use client'

/**
 * MarketCommandHeader: the terminal shell (News Catalyst Terminal look, app-wide).
 *
 *   Row 1  ◉ SURYADHANA ▸ PAGE · NIFTY 50 live (O/H/L) · service lights · IST clock · refresh
 *   Row 2  macro tape: NIFTY, BANK NIFTY, INDIA VIX, USD/INR, BRENT, GOLD, S&P 500 (60 s)
 *   Row 3  page strip with keyboard shortcuts (Alt+1…9, Alt+0)
 *
 * Data: NIFTY from the ICICI websocket when it is streaming, else NSE's live index (/api/market/nifty-live, ≈1 min
 * delayed), else the last stored ICICI quote (marked STALE).
 * (5 s poll); macro tape from /api/news-scanner/quotes (Yahoo, 60 s).
 */
import { Z } from '@/lib/z'
import { useEffect, useRef, useState } from 'react'
import { useLiveQuotes, useDataServiceStatus } from '@/context/AppContext'
import { getNewsQuotes, getGiftNifty, getIndicesLive, type GiftNifty } from '@/lib/api'
import { AlertsBell } from '@/components/AlertsBell'
import { T } from '@/components/terminal'
import { goToPage } from '@/lib/navigate'

// ── IST clock + session state ─────────────────────────────────────────────────

function useIST() {
  const [now, setNow] = useState<Date | null>(null)
  useEffect(() => {
    const tick = () => setNow(new Date(new Date().toLocaleString('en-US', { timeZone: 'Asia/Kolkata' })))
    tick()
    const id = setInterval(tick, 1000)
    return () => clearInterval(id)
  }, [])
  return now
}

function sessionState(now: Date | null): { label: string; color: string } {
  if (!now) return { label: '—', color: T.muted }
  const d = now.getDay(), m = now.getHours() * 60 + now.getMinutes()
  if (d === 0 || d === 6) return { label: 'WEEKEND', color: T.muted }
  if (m >= 9 * 60 && m < 9 * 60 + 15) return { label: 'PRE-OPEN', color: T.amber }
  if (m >= 9 * 60 + 15 && m < 15 * 60 + 30) return { label: 'NSE OPEN', color: T.green }
  if (m >= 15 * 60 + 30 && m < 16 * 60) return { label: 'CLOSING', color: T.amber }
  return { label: 'CLOSED', color: T.muted }
}

// ── NIFTY live ────────────────────────────────────────────────────────────────

function NiftyLive() {
  const { liveQuotes, wsConnected } = useLiveQuotes()
  const [http, setHttp] = useState<any>(null)
  const [nse, setNse] = useState<any>(null)
  useEffect(() => {
    let cancelled = false
    const poll = async () => {
      try { const res = await fetch('/api/market/nifty-live'); if (!cancelled && res.ok) setNse(await res.json()) } catch { /* next poll */ }
    }
    poll()
    const id = setInterval(poll, 15_000)
    return () => { cancelled = true; clearInterval(id) }
  }, [])
  const [flash, setFlash] = useState<'up' | 'down' | null>(null)
  const prev = useRef<number | null>(null)

  useEffect(() => {
    let cancelled = false
    const poll = async () => {
      try {
        const res = await fetch('/api/data/live/index/nifty')
        if (!cancelled && res.ok) setHttp(await res.json())
      } catch { /* backend restarting: next poll */ }
    }
    poll()
    const id = setInterval(poll, 5000)
    return () => { cancelled = true; clearInterval(id) }
  }, [])

  const ws = liveQuotes['NIFTY'] || liveQuotes['NSEI']
  const rec = (() => {
    const p = http?.record?.payload
    if (!p) return null
    if (typeof p === 'string') { try { return JSON.parse(p) } catch { return null } }
    return p
  })()
  // source: ICICI stream → NSE live index → last stored ICICI quote (which can be yesterday's)
  const src: 'ICICI' | 'NSE' | 'STALE' | null = ws?.ltp != null ? 'ICICI' : nse?.last != null ? 'NSE' : rec?.ltp != null ? 'STALE' : null
  const ltp: number | null = src === 'ICICI' ? ws.ltp : src === 'NSE' ? nse.last : rec?.ltp ?? null
  const pc: number | null = src === 'ICICI' ? ws?.raw?.previous_close ?? null : src === 'NSE' ? nse.previous_close : rec?.previous_close ?? null
  const chg = src === 'NSE' ? nse.change : ltp != null && pc != null ? ltp - pc : ws?.change ?? null
  const pct = src === 'NSE' ? nse.change_pct
    : ws?.change_pct ?? ws?.raw?.ltp_percent_change ?? rec?.ltp_percent_change ?? (chg != null && pc ? (chg / pc) * 100 : null)
  const o = src === 'NSE' ? nse.open : ws?.raw?.open ?? rec?.open
  const h = src === 'NSE' ? nse.high : ws?.raw?.high ?? rec?.high
  const l = src === 'NSE' ? nse.low : ws?.raw?.low ?? rec?.low

  useEffect(() => {
    if (ltp == null) return
    if (prev.current != null && ltp !== prev.current) {
      setFlash(ltp > prev.current ? 'up' : 'down')
      const t = setTimeout(() => setFlash(null), 700)
      prev.current = ltp
      return () => clearTimeout(t)
    }
    prev.current = ltp
  }, [ltp])

  const up = (chg ?? 0) >= 0
  const n = (v: any) => v == null ? '—' : Number(v).toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 })
  return (
    <div style={{ display: 'flex', alignItems: 'center', gap: 14, padding: '0 16px', borderLeft: `1px solid ${T.border}`,
                  borderRight: `1px solid ${T.border}`, height: '100%' }}>
      <span style={{ fontSize: 10, letterSpacing: 1.4, color: T.muted }}>NIFTY 50</span>
      <span style={{ fontSize: 17, fontWeight: 700, letterSpacing: .3,
                     color: flash === 'up' ? T.green : flash === 'down' ? T.red : T.bright,
                     background: flash ? (flash === 'up' ? 'rgba(22,217,138,.12)' : 'rgba(255,77,94,.12)') : 'transparent',
                     padding: '0 4px', transition: 'background .3s' }}>{n(ltp)}</span>
      <span style={{ fontSize: 12, fontWeight: 600, color: chg == null ? T.muted : up ? T.green : T.red, whiteSpace: 'nowrap' }}>
        {chg == null ? '' : `${up ? '▲' : '▼'} ${Math.abs(chg).toFixed(2)}  ${pct != null ? `${up ? '+' : '−'}${Math.abs(Number(pct)).toFixed(2)}%` : ''}`}
      </span>
      <span className="t-hide-lg" style={{ fontSize: 10, color: T.dim, display: 'flex', gap: 10, whiteSpace: 'nowrap' }}>
        <span>O <span style={{ color: T.muted }}>{n(o)}</span></span>
        <span>H <span style={{ color: T.muted }}>{n(h)}</span></span>
        <span>L <span style={{ color: T.muted }}>{n(l)}</span></span>
      </span>
      <span title={src === 'ICICI' ? 'ICICI Breeze stream' : src === 'NSE' ? `NSE live index, ≈1 min delayed${nse?.time ? ` · ${nse.time}` : ''}` : 'last stored ICICI quote: may be from an earlier session'}
            style={{ fontSize: 9, letterSpacing: 1, padding: '2px 6px', whiteSpace: 'nowrap',
                     border: `1px solid ${src === 'ICICI' ? T.green : src === 'NSE' ? T.cyan : T.border}`,
                     color: src === 'ICICI' ? T.green : src === 'NSE' ? T.cyan : T.muted }}>
        {src === 'ICICI' ? (wsConnected ? '● LIVE' : '● ICICI') : src === 'NSE' ? '● NSE' : '◌ STALE'}</span>
    </div>
  )
}

// ── macro tape ────────────────────────────────────────────────────────────────

// Indian indices come from NSE (`nse` = allIndices name); Yahoo's can lag a whole session after the close
const MACRO: { sym: string; label: string; digits?: number; nse?: string }[] = [
  { sym: '^NSEI', label: 'NIFTY 50', nse: 'NIFTY 50' },
  { sym: '^NSEBANK', label: 'BANK NIFTY', nse: 'NIFTY BANK' },
  { sym: '^INDIAVIX', label: 'INDIA VIX', nse: 'INDIA VIX' },
  { sym: 'INR=X', label: 'USD/INR', digits: 3 },
  { sym: 'BZ=F', label: 'BRENT' },
  { sym: 'GC=F', label: 'GOLD' },
  { sym: '^GSPC', label: 'S&P 500' },
]

function MacroTape() {
  const [q, setQ] = useState<Record<string, any>>({})
  const [at, setAt] = useState<string>('')
  const [gift, setGift] = useState<GiftNifty | null>(null)
  useEffect(() => {
    let cancelled = false
    const load = async () => {
      getGiftNifty().then(r => { if (!cancelled) setGift(r.data) }).catch(() => {})
      try {
        const [r, nse] = await Promise.all([getNewsQuotes(MACRO.filter(m => !m.nse).map(m => m.sym)),
                                            getIndicesLive(MACRO.filter(m => m.nse).map(m => m.nse!)).catch(() => null)])
        if (!cancelled) {
          const merged: Record<string, any> = { ...(r.data?.quotes ?? {}) }
          for (const m of MACRO) {
            const v = m.nse ? nse?.data?.indices?.[m.nse] : null
            if (v?.last != null) merged[m.sym] = { price: v.last, change_pct: v.change_pct, source: 'NSE' }
          }
          setQ(merged)
          setAt(new Date().toLocaleTimeString('en-IN', { timeZone: 'Asia/Kolkata', hour12: false, hour: '2-digit', minute: '2-digit' }))
        }
      } catch { /* keep last values */ }
    }
    load()
    const id = setInterval(load, 60_000)
    return () => { cancelled = true; clearInterval(id) }
  }, [])
  return (
    <div style={{ display: 'flex', alignItems: 'center', height: 26, borderBottom: `1px solid ${T.border}`,
                  background: '#06080c', overflowX: 'auto', whiteSpace: 'nowrap' }}>
      <span style={{ background: T.amber, color: T.bg, fontSize: 9, fontWeight: 700, letterSpacing: 1.2,
                     padding: '0 8px', height: '100%', display: 'flex', alignItems: 'center', flex: 'none' }}>MARKETS</span>
      {gift?.last != null && (
        <span title={`GIFT NIFTY (NSE IX) at ${gift.time}: implies ${gift.implied_gap_pct ?? '—'}% vs NIFTY's last close`}
              style={{ display: 'inline-flex', gap: 7, alignItems: 'baseline', padding: '0 14px', borderRight: `1px solid ${T.border}`, fontSize: 11 }}>
          <span style={{ color: T.amber, fontSize: 10, letterSpacing: .8 }}>GIFT NIFTY</span>
          <span style={{ color: T.text }}>{gift.last.toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</span>
          {gift.implied_gap_pct != null && <span style={{ color: gift.implied_gap_pct >= 0 ? T.green : T.red }}>{gift.implied_gap_pct >= 0 ? '+' : '−'}{Math.abs(gift.implied_gap_pct).toFixed(2)}%{' '}
            {gift.nifty_status === 'Open' ? 'vs spot' : 'gap'}</span>}
        </span>
      )}
      {MACRO.map((m, i) => {
        const v = q[m.sym]
        const c = v?.change_pct
        const col = c == null ? T.muted : c >= 0 ? T.green : T.red
        // narrow terminals drop tape entries from the right instead of scrolling (720/1024/1280)
        const slice = i >= 6 ? 't-tape-ge6' : i >= 4 ? 't-tape-ge4' : i >= 2 ? 't-tape-ge2' : undefined
        return (
          <span key={m.sym} className={slice}
                style={{ display: 'inline-flex', gap: 7, alignItems: 'baseline', padding: '0 14px',
                         borderRight: `1px solid ${T.border}`, fontSize: 11 }}>
            <span style={{ color: T.muted, fontSize: 10, letterSpacing: .8 }}>{m.label}</span>
            <span style={{ color: T.text }}>{v?.price != null ? Number(v.price).toLocaleString('en-IN', { maximumFractionDigits: m.digits ?? 2, minimumFractionDigits: m.digits ?? 2 }) : '—'}</span>
            <span style={{ color: col }}>{c == null ? '' : `${c >= 0 ? '+' : '−'}${Math.abs(c).toFixed(2)}%`}</span>
          </span>
        )
      })}
      <span style={{ flex: 1 }} />
      <span className="t-tape-ge2" style={{ fontSize: 9, color: T.dim, padding: '0 12px', flex: 'none' }}>{at && `NSE + YAHOO · ${at} IST`}</span>
    </div>
  )
}

// ── page strip ────────────────────────────────────────────────────────────────

type MorePage = { id: string; code: string; label: string; hint: string }

/** "MORE ▾": the pages that live outside the strip (also on GO). The menu is fixed-positioned so the strip's
 *  horizontal scroll doesn't clip it. */
function MoreMenu({ pages, active, onChange }: { pages: MorePage[]; active: string; onChange: (id: string) => void }) {
  const [open, setOpen] = useState(false)
  const [at, setAt] = useState<{ top: number; right: number }>({ top: 0, right: 0 })
  const btn = useRef<HTMLButtonElement>(null)
  const current = pages.find(p => p.id === active)
  useEffect(() => {
    if (!open) return
    const close = (e: MouseEvent | KeyboardEvent) => {
      if (e instanceof KeyboardEvent ? e.key === 'Escape' : !(e.target as HTMLElement).closest('[data-more-menu]')) setOpen(false)
    }
    window.addEventListener('mousedown', close); window.addEventListener('keydown', close)
    return () => { window.removeEventListener('mousedown', close); window.removeEventListener('keydown', close) }
  }, [open])
  const toggle = () => {
    const r = btn.current?.getBoundingClientRect()
    if (r) setAt({ top: r.bottom, right: Math.max(8, window.innerWidth - r.right) })
    setOpen(o => !o)
  }
  return (
    <>
      <button ref={btn} data-more-menu onClick={toggle} title="More pages (also on GO)"
        style={{ display: 'flex', alignItems: 'center', gap: 6, padding: '8px 12px', flex: 'none',
                 background: current ? '#0e131c' : '#0b0f16', border: 'none', borderLeft: `1px solid ${T.borderHi}`, cursor: 'pointer',
                 borderBottom: `2px solid ${current ? T.amber : 'transparent'}` }}>
        <span style={{ fontFamily: T.display, fontSize: 11, fontWeight: 700, letterSpacing: 1, color: current ? T.amber : T.cyan }}>
          {current ? current.code : 'MORE'} ▾
        </span>
      </button>
      {open && (
        <div data-more-menu style={{ position: 'fixed', top: at.top, right: at.right, zIndex: Z.dropdown, minWidth: 340, background: '#0b0f16',
                                     border: `1px solid ${T.borderHi}`, boxShadow: '0 12px 32px rgba(0,0,0,.6)', padding: '4px 0' }}>
          <div style={{ fontSize: 9, color: T.dim, letterSpacing: 1, padding: '6px 12px' }}>MORE PAGES · OR TYPE THE CODE IN ⌕ GO</div>
          {pages.map(p => (
            <button key={p.id} onClick={() => { onChange(p.id); setOpen(false) }}
              style={{ display: 'grid', gridTemplateColumns: '52px 1fr', gap: 8, width: '100%', textAlign: 'left', padding: '6px 12px',
                       background: p.id === active ? '#121a26' : 'transparent', border: 'none', cursor: 'pointer', alignItems: 'baseline' }}>
              <span style={{ fontFamily: T.mono, fontSize: 11, fontWeight: 700, color: T.amber }}>{p.code}</span>
              <span><span style={{ fontSize: 11.5, color: T.text }}>{p.label}</span>
                <span style={{ display: 'block', fontSize: 10, color: T.dim }}>{p.hint}</span></span>
            </button>
          ))}
        </div>
      )}
    </>
  )
}

function PageStrip({ tabs, more = [], active, onChange }: {
  tabs: { id: string; label: string; badge?: number }[]; more?: MorePage[]; active: string; onChange: (id: string) => void
}) {
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (!e.altKey || e.ctrlKey || e.metaKey) return
      const k = e.code.startsWith('Digit') ? e.code.slice(5) : null
      if (k == null) return
      const i = k === '0' ? 9 : Number(k) - 1
      if (tabs[i]) { e.preventDefault(); onChange(tabs[i].id) }
    }
    window.addEventListener('keydown', onKey)
    return () => window.removeEventListener('keydown', onKey)
  }, [tabs, onChange])
  useEffect(() => {
    document.querySelector(`[data-tab="${active}"]`)?.scrollIntoView({ block: 'nearest', inline: 'nearest' })
  }, [active])
  return (
    <nav style={{ display: 'flex', overflowX: 'auto', borderBottom: `1px solid ${T.border}`, background: '#07090d' }}>
      {tabs.map((t, i) => {
        const on = t.id === active
        const key = i < 9 ? String(i + 1) : i === 9 ? '0' : null
        return (
          <button key={t.id} data-tab={t.id} onClick={() => onChange(t.id)} title={key ? `Alt+${key}` : undefined}
            style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 4, padding: '8px 5px', whiteSpace: 'nowrap', flex: '1 0 auto',
                     background: on ? '#0e131c' : 'transparent', border: 'none', cursor: 'pointer',
                     borderBottom: `2px solid ${on ? T.amber : 'transparent'}`, borderRight: `1px solid ${T.border}` }}>
            {key && <span style={{ fontSize: 9, color: on ? T.bg : T.dim, background: on ? T.amber : 'transparent',
                                   border: `1px solid ${on ? T.amber : T.border}`, padding: '0 4px', lineHeight: '14px' }}>{key}</span>}
            <span style={{ fontFamily: T.display, fontSize: 11, fontWeight: 600, letterSpacing: .55,
                           textTransform: 'uppercase', color: on ? T.amber : T.muted }}>{t.label}</span>
            {t.badge ? <span style={{ fontSize: 9, color: T.bg, background: T.cyan, padding: '0 5px' }}>{t.badge}</span> : null}
          </button>
        )
      })}
      <div style={{ position: 'sticky', right: 0, display: 'flex', flex: 'none', background: '#0b0f16' }}>
      {more.length > 0 && <MoreMenu pages={more} active={active} onChange={onChange} />}
      <button onClick={() => window.dispatchEvent(new Event('suryadhana:command'))} title="Command bar — type a ticker or function code (/ or Ctrl+K)"
        style={{ display: 'flex', alignItems: 'center', gap: 6, padding: '8px 12px', flex: 'none',
                 background: '#0b0f16', border: 'none', borderLeft: `1px solid ${T.borderHi}`, cursor: 'pointer' }}>
        <span style={{ fontFamily: T.display, fontSize: 11.5, fontWeight: 700, letterSpacing: 1.2, color: T.amber }}>⌕ GO</span>
        <span style={{ fontSize: 9, color: T.dim, border: `1px solid ${T.border}`, padding: '0 4px', lineHeight: '14px' }}>/</span>
      </button>
      </div>
    </nav>
  )
}

// ── header ────────────────────────────────────────────────────────────────────

interface Props {
  onRefresh: () => void
  refreshing: boolean
  totalStocks: number
  latestDate?: string
  activeTab: string
  tabs: { id: string; label: string; badge?: number }[]
  more?: MorePage[]
  onTabChange: (id: string) => void
}

function Light({ name, ok, detail, onClick }: { name: string; ok: boolean | null; detail?: string; onClick?: () => void }) {
  const c = ok === true ? T.green : ok === false ? T.red : T.dim
  return (
    <span title={detail || name} role={onClick ? 'button' : undefined} onClick={onClick}
          style={{ display: 'inline-flex', alignItems: 'center', gap: 5, fontSize: 9.5, cursor: onClick ? 'pointer' : 'default',
                   letterSpacing: 1.1, color: ok === false ? T.red : T.muted }}>
      <span style={{ width: 6, height: 6, borderRadius: 6, background: c, boxShadow: ok ? `0 0 6px ${c}` : 'none' }} />
      {name}
    </span>
  )
}

export function MarketCommandHeader({ onRefresh, refreshing, totalStocks, latestDate, activeTab, tabs, more = [], onTabChange }: Props) {
  const { dataServiceStatus: ds } = useDataServiceStatus()
  const now = useIST()
  const sess = sessionState(now)
  // pages outside the strip show their function code (WRAP, MOV…): long labels crowd the header row
  const page = tabs.find(t => t.id === activeTab)?.label ?? more.find(m => m.id === activeTab)?.code ?? activeTab
  return (
    <header style={{ position: 'sticky', top: 0, zIndex: Z.header, background: T.bg, fontFamily: T.mono }}>
      <div style={{ height: 44, display: 'flex', alignItems: 'center', borderBottom: `1px solid ${T.border}`, background: '#07090d' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 10, padding: '0 16px', height: '100%' }}>
          <span style={{ fontFamily: T.display, fontWeight: 700, letterSpacing: 2, color: T.amber, fontSize: 14, whiteSpace: 'nowrap' }}>
            ◉ SURYADHANA <span style={{ color: T.dim }}>▸</span> <span style={{ color: T.bright }}>{page.toUpperCase()}</span>
          </span>
          <span className="t-hide-lg" style={{ fontSize: 9.5, color: T.dim, letterSpacing: 1, whiteSpace: 'nowrap' }}>
            {totalStocks ? `${totalStocks.toLocaleString('en-IN')} NSE` : ''}{latestDate ? ` · DATA ${latestDate}` : ''}
          </span>
        </div>
        <NiftyLive />
        <span style={{ flex: 1 }} />
        <div style={{ display: 'flex', gap: 12, padding: '0 14px', borderLeft: `1px solid ${T.border}`, height: '100%', alignItems: 'center' }}>
          <Light name="DATA" ok={ds.health === 'ok' ? true : ds.health === 'error' ? false : null} detail={`data-service: ${ds.health}`} />
          <Light name="DB" ok={ds.ready} detail="DuckDB ready" />
          <Light name="ICICI" ok={ds.connected}
                 detail={ds.connected ? `ICICI Breeze connected (${ds.provider ?? 'provider'})` : 'ICICI not connected: click to log in on the Broker tab'}
                 onClick={ds.connected ? undefined : () => goToPage('broker')} />
        </div>
        <div style={{ display: 'flex', alignItems: 'center', gap: 10, padding: '0 14px', borderLeft: `1px solid ${T.border}`, height: '100%' }}>
          <span style={{ fontSize: 9.5, letterSpacing: 1.2, color: sess.color, border: `1px solid ${sess.color === T.muted ? T.border : sess.color}`,
                         padding: '2px 6px', whiteSpace: 'nowrap' }}>{sess.label}</span>
          <span style={{ fontSize: 13, fontWeight: 600, color: T.bright }}>
            {now ? now.toLocaleTimeString('en-IN', { hour12: false }) : '--:--:--'}
          </span>
          <span className="t-hide-lg" style={{ fontSize: 9.5, color: T.dim, letterSpacing: 1, whiteSpace: 'nowrap' }}>
            {now ? now.toLocaleDateString('en-IN', { weekday: 'short', day: '2-digit', month: 'short' }).toUpperCase() : ''} IST
          </span>
        </div>
        <div style={{ padding: '0 12px', borderLeft: `1px solid ${T.border}`, height: '100%', display: 'flex', alignItems: 'center', gap: 8 }}>
          <AlertsBell />
          <button onClick={onRefresh} disabled={refreshing} title="Refresh NSE data"
            style={{ fontFamily: T.mono, fontSize: 10, letterSpacing: 1.2, color: refreshing ? T.muted : T.amber, whiteSpace: 'nowrap',
                     background: 'transparent', border: `1px solid ${T.border}`, padding: '4px 9px', cursor: refreshing ? 'wait' : 'pointer' }}>
            <span className={refreshing ? 't-pulse' : undefined}>↻</span> REFRESH
          </button>
        </div>
      </div>
      <MacroTape />
      <PageStrip tabs={tabs} more={more} active={activeTab} onChange={onTabChange} />
    </header>
  )
}
