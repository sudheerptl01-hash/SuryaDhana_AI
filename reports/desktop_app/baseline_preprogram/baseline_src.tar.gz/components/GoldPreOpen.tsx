'use client'

import { apiError } from '@/lib/errors'
/**
 * Gold Pre-Open desk — where MCX Gold should open, and whether the opening price is worth chasing.
 *
 *   fair open = MCX settlement × (COMEX now ÷ COMEX at the MCX close) × (USD/INR now ÷ USD/INR at the close)
 *
 * Data: /api/commodity/gold-preopen (services/ui-api/routers/gold_preopen.py). The baseline is read
 * automatically from ICICI's public contract file; the trader can override it and enter the MCX
 * price at the open (or connect ICICI Breeze for it). Inputs and checklist ticks persist for the day.
 */
import { useCallback, useEffect, useMemo, useRef, useState } from 'react'
import { getGoldPreOpen, type GoldContextRow, type GoldPreOpen as Data } from '@/lib/api'
import { Chip, DataTable, Input, Label, Loading, Notice, Panel, Stat, T, fmtInr, type Column, fmtNum } from '@/components/terminal'
import { GoldAccuracyLog } from './GoldAccuracyLog'

const REFRESH_MS = 60_000
const todayKey = () => new Date().toLocaleDateString('en-CA', { timeZone: 'Asia/Kolkata' })
const STORE = 'goldPreOpen.v1'

interface Saved { day: string; baseline: string; mcx: string; threshold: string; trigger: string; done: Record<string, boolean> }
const blank = (): Saved => ({ day: todayKey(), baseline: '', mcx: '', threshold: '300', trigger: '1.1161', done: {} })

function load(): Saved {
  try {
    const s = JSON.parse(localStorage.getItem(STORE) || 'null') as Saved | null
    if (!s) return blank()
    // Day-specific entries (close override, MCX price, ticks) reset each day; settings carry over.
    return s.day === todayKey() ? s : { ...blank(), threshold: s.threshold, trigger: s.trigger }
  } catch { return blank() }
}
function save(s: Saved) { try { localStorage.setItem(STORE, JSON.stringify(s)) } catch { /* storage unavailable */ } }

const num = (s: string) => { const v = Number(String(s).replace(/[,₹\s]/g, '')); return Number.isFinite(v) && v > 0 ? v : undefined }
const signed = (v: number | null | undefined, digits = 0) =>
  v == null || !Number.isFinite(v) ? '—' : `${v > 0 ? '+' : v < 0 ? '−' : ''}${fmtInr(Math.abs(v), digits).replace('−', '')}`
const fx = (v: number | null | undefined, d = 2) => fmtNum(v, d)
const ago = (iso: string) => {
  const m = Math.max(0, Math.round((Date.now() - new Date(iso).getTime()) / 60000))
  return m < 60 ? `${m}m` : m < 1440 ? `${Math.round(m / 60)}h` : `${Math.round(m / 1440)}d`
}
const istTime = (iso?: string | null) => iso
  ? new Date(iso).toLocaleString('en-IN', { timeZone: 'Asia/Kolkata', day: '2-digit', month: 'short', hour: '2-digit', minute: '2-digit', hour12: false })
  : '—'

const VERDICT_STYLE: Record<string, { color: string; glyph: string }> = {
  OK: { color: T.green, glyph: '▲' },
  WAIT: { color: T.red, glyph: '■' },
  AWAITING_OPEN: { color: T.amber, glyph: '◷' },
  NEED_PRICE: { color: T.cyan, glyph: '◇' },
  NO_MODEL: { color: T.muted, glyph: '◌' },
}

/** Settlement → +COMEX → +rupee → fair, as a horizontal waterfall. */
function Waterfall({ base, comex, inr }: { base: number; comex: number; inr: number }) {
  const fair = base + comex + inr
  const lo = Math.min(base, base + comex, fair), hi = Math.max(base, base + comex, fair)
  const pad = Math.max((hi - lo) * 0.25, 50)
  const x = (v: number) => ((v - (lo - pad)) / (hi - lo + 2 * pad)) * 100
  const bar = (from: number, to: number, color: string, label: string, y: number) => (
    <g key={label}>
      <rect x={`${Math.min(x(from), x(to))}%`} y={y} width={`${Math.max(Math.abs(x(to) - x(from)), 0.4)}%`} height={12} fill={color} opacity={0.85} />
      <text x={`${Math.max(x(from), x(to)) + 1}%`} y={y + 10} fill={T.muted} fontSize={10} fontFamily={T.mono}>{label}</text>
    </g>
  )
  return (
    <svg width="100%" height={70} role="img" aria-label="Gap build-up">
      <line x1={`${x(base)}%`} x2={`${x(base)}%`} y1={0} y2={70} stroke={T.borderHi} strokeDasharray="2 3" />
      {bar(base, base + comex, comex >= 0 ? T.green : T.red, `COMEX ${signed(comex)}`, 6)}
      {bar(base + comex, fair, inr >= 0 ? T.green : T.red, `Rupee ${signed(inr)}`, 28)}
      {bar(base, fair, T.amber, `Gap ${signed(fair - base)}`, 50)}
    </svg>
  )
}

export function GoldPreOpen() {
  const [saved, setSaved] = useState<Saved>(blank)
  const [data, setData] = useState<Data | null>(null)
  const [error, setError] = useState<string | null>(null)
  const [loading, setLoading] = useState(false)
  const reqId = useRef(0)

  useEffect(() => { setSaved(load()) }, [])
  const update = (patch: Partial<Saved>) => setSaved(s => { const n = { ...s, ...patch, day: todayKey() }; save(n); return n })

  const params = useMemo(() => ({
    baseline: num(saved.baseline), mcx_price: num(saved.mcx),
    threshold: num(saved.threshold) ?? 300, eurusd_trigger: num(saved.trigger) ?? 1.1161,
  }), [saved.baseline, saved.mcx, saved.threshold, saved.trigger])

  const fetchData = useCallback(async () => {
    const id = ++reqId.current
    setLoading(true)
    try {
      const r = await getGoldPreOpen(params)
      if (id === reqId.current) { setData(r.data); setError(null) }
    } catch (e: any) {
      if (id === reqId.current) setError(apiError(e, 'Gold desk unavailable'))
    } finally {
      if (id === reqId.current) setLoading(false)
    }
  }, [params])

  useEffect(() => {                                   // debounce typing, then refresh every minute
    const t = setTimeout(fetchData, 400)
    const iv = setInterval(fetchData, REFRESH_MS)
    return () => { clearTimeout(t); clearInterval(iv) }
  }, [fetchData])

  const m = data?.model ?? {}
  const v = data?.verdict
  const vs = VERDICT_STYLE[v?.state ?? 'NO_MODEL']
  const base = data?.baseline.value ?? null
  const mcxNow = data?.mcx_price.value ?? null
  const diff = mcxNow != null && m.fair_open != null ? mcxNow - m.fair_open : null
  const lot = m.lot_pnl_per_rupee ?? 100
  const doneCount = Object.values(saved.done).filter(Boolean).length
  const istNow = new Date(new Date().toLocaleString('en-US', { timeZone: 'Asia/Kolkata' }))
  const marketOpen = istNow.getDay() >= 1 && istNow.getDay() <= 5 && istNow.getHours() * 60 + istNow.getMinutes() >= 9 * 60

  const ctxCols: Column<GoldContextRow>[] = [
    { key: 'label', label: 'Indicator', render: r => <span style={{ color: T.text }}>{r.label} <span style={{ color: T.dim, fontSize: 10 }}>{r.symbol}</span></span> },
    { key: 'value', label: 'Now', align: 'right', render: r => <span style={{ color: T.bright }}>{fx(r.value, r.key === 'eurusd' ? 4 : 2)}{r.unit === '%' ? '%' : ''}</span> },
    { key: 'at_close', label: 'At MCX close', align: 'right', render: r => <span style={{ color: T.muted }}>{fx(r.at_close, r.key === 'eurusd' ? 4 : 2)}</span> },
    { key: 'change', label: 'Change', align: 'right', sort: r => r.change ?? 0,
      render: r => <span style={{ color: r.change == null ? T.muted : r.change > 0 ? T.green : r.change < 0 ? T.red : T.muted }}>
        {r.change == null ? '—' : `${r.change > 0 ? '+' : ''}${fx(r.change, r.key === 'eurusd' ? 4 : r.unit === '%' ? 3 : 2)}`}</span> },
    { key: 'signal', label: 'For gold', align: 'center',
      render: r => r.signal ? <Chip color={r.signal === 'supportive' ? T.green : T.red}>{r.signal === 'supportive' ? '▲ SUPPORTIVE' : '▼ HEADWIND'}</Chip>
        : <span style={{ color: T.dim }}>flat</span> },
    { key: 'note', label: 'Note', render: r => r.key === 'eurusd' && r.trigger
      ? <span style={{ color: r.trigger_state === 'above' ? T.green : T.amber }}>{r.trigger_state} the {fx(r.trigger, 4)} trigger</span>
      : <span style={{ color: T.dim }}>{r.note ?? ''}</span> },
  ]

  return (
    <Panel title="Gold Pre-Open Desk" accent={T.amber}
      subtitle={data ? `${data.contract.name} ↔ COMEX ${data.contract.comex.replace('.CMX', '')} · updated ${istTime(data.as_of)} IST · auto every 60 s` : 'MCX gold fair open from COMEX and the rupee'}
      right={<>
        {loading && <span className="t-pulse" style={{ fontSize: 10, color: T.amber }}>UPDATING</span>}
        <Chip color={T.amber} onClick={fetchData} title="Recompute now">↻ REFRESH</Chip>
      </>}
      style={{ marginBottom: 16 }} bodyStyle={{ display: 'grid', gap: 12 }}>

      {error && <Notice color={T.red}>Gold desk unavailable: {error}</Notice>}
      {!data && !error && <Loading label="Computing fair open from COMEX, the rupee and the MCX settlement" />}
      {data && <>

      {/* 1. verdict */}
      {v && (
        <div style={{ display: 'flex', alignItems: 'center', gap: 16, padding: '14px 18px', border: `1px solid ${vs.color}`,
                      background: `${vs.color}12`, flexWrap: 'wrap' }}>
          <span style={{ fontSize: 26, color: vs.color, lineHeight: 1 }}>{vs.glyph}</span>
          <div style={{ flex: 1, minWidth: 260 }}>
            <div style={{ fontFamily: T.display, fontSize: 22, fontWeight: 700, letterSpacing: 1.4, color: vs.color, textTransform: 'uppercase' }}>{v.title}</div>
            <div style={{ fontSize: 12, color: T.text, marginTop: 4 }}>{v.detail}</div>
          </div>
          {data?.event_risk.advice
            ? <Chip color={T.red} title={`${data.event_risk.flagged_headlines} headlines mention war, strikes, sanctions, margins or halts`}>⚠ EVENT RISK · {data.event_risk.advice}</Chip>
            : <Chip color={T.green}>NO EVENT FLAGS</Chip>}
        </div>
      )}

      {/* 2. key numbers */}
      <div style={{ display: 'grid', gap: 10, gridTemplateColumns: 'repeat(auto-fit, minmax(190px, 1fr))' }}>
        <Stat label="Baseline · MCX close" value={fmtInr(base)} accent={T.violet}
          sub={data?.baseline.source ? `${data.baseline.source}` : 'enter your close below'} />
        <Stat label={marketOpen ? 'Fair value now (model)' : 'Fair open (model)'} value={fmtInr(m.fair_open)} accent={T.amber} color={T.amber}
          sub={m.gap_pct != null ? `${m.gap_pct > 0 ? '+' : ''}${m.gap_pct.toFixed(2)}% vs baseline` : '—'} />
        <Stat label="Expected gap" value={signed(m.gap)} color={(m.gap ?? 0) >= 0 ? T.green : T.red} accent={(m.gap ?? 0) >= 0 ? T.green : T.red}
          sub={m.gap != null ? `${signed(m.gap * lot)} per 1 kg lot · ${signed(m.gap * 10)} per Gold Mini` : '—'} />
        <Stat label="MCX now vs fair" value={diff == null ? '—' : signed(diff)} accent={T.cyan}
          color={diff == null ? T.muted : Math.abs(diff) <= (data?.threshold ?? 300) ? T.green : T.red}
          sub={mcxNow != null ? `MCX ${fmtInr(mcxNow)} · ${data?.mcx_price.source}` : 'enter the MCX price at the open'} />
        <Stat label="Chase limit" value={fmtInr(data?.threshold ?? 300)} accent={T.border}
          sub={m.threshold_in_comex_dollars != null ? `≈ $${m.threshold_in_comex_dollars} on COMEX · ${signed((data?.threshold ?? 300) * lot)} per lot` : ''} />
      </div>

      {/* 3. gap build-up + inputs */}
      <div style={{ display: 'grid', gap: 12, gridTemplateColumns: 'minmax(0, 1.6fr) minmax(280px, 1fr)' }}>
        <Panel title="Gap build-up" subtitle="what moved since MCX closed" accent={T.cyan} pad={10}>
          <table style={{ width: '100%', borderCollapse: 'collapse', fontFamily: T.mono, fontSize: 11 }}>
            <thead><tr style={{ color: T.muted, textAlign: 'right', fontSize: 10, letterSpacing: .6 }}>
              <th style={{ textAlign: 'left', padding: '4px 6px' }}>DRIVER</th><th>AT MCX CLOSE</th><th>NOW</th><th>CHANGE</th><th style={{ padding: '4px 6px' }}>IMPACT ON MCX</th>
            </tr></thead>
            <tbody>
              {[['COMEX gold', m.comex, m.comex_part, 1, '$'], ['USD / INR', m.inr, m.inr_part, 3, '₹']].map(([name, leg, part, d, ccy]: any) => (
                <tr key={name} style={{ borderTop: `1px solid ${T.border}`, textAlign: 'right' }}>
                  <td style={{ textAlign: 'left', padding: '6px', color: T.text }}>{name} <span style={{ color: T.dim, fontSize: 10 }}>{leg?.symbol}</span>
                    <div style={{ color: T.dim, fontSize: 9 }}>{leg?.ref_how}</div></td>
                  <td style={{ color: T.muted }}>{leg?.ref != null ? `${ccy}${fx(leg.ref, d)}` : '—'}</td>
                  <td style={{ color: T.bright }}>{leg ? `${ccy}${fx(leg.now, d)}` : '—'}</td>
                  <td style={{ color: leg && leg.ref != null ? (leg.now - leg.ref >= 0 ? T.green : T.red) : T.muted }}>
                    {leg && leg.ref != null ? `${leg.now - leg.ref >= 0 ? '+' : ''}${fx(leg.now - leg.ref, d)}` : '—'}</td>
                  <td style={{ padding: '6px', color: (part ?? 0) >= 0 ? T.green : T.red, fontWeight: 600 }}>{signed(part)}</td>
                </tr>
              ))}
              <tr style={{ borderTop: `1px solid ${T.borderHi}`, textAlign: 'right' }}>
                <td style={{ textAlign: 'left', padding: '6px', color: T.amber, fontWeight: 700 }}>FAIR OPEN</td>
                <td style={{ color: T.muted }}>{fmtInr(base)}</td><td style={{ color: T.amber }}>{fmtInr(m.fair_open)}</td>
                <td /><td style={{ padding: '6px', color: (m.gap ?? 0) >= 0 ? T.green : T.red, fontWeight: 700 }}>{signed(m.gap)}</td>
              </tr>
            </tbody>
          </table>
          {base != null && m.comex_part != null && m.inr_part != null && <Waterfall base={base} comex={m.comex_part} inr={m.inr_part} />}
          <div style={{ fontSize: 10, color: T.muted, lineHeight: 1.6 }}>
            Rule of thumb today: <b style={{ color: T.text }}>₹{fx(m.rs_per_comex_dollar, 1)}</b> per $1 on COMEX ·
            <b style={{ color: T.text }}> ₹{fx(m.rs_per_inr_rupee, 0)}</b> per ₹1 on USD/INR · MCX trades at a
            <b style={{ color: T.text }}> {fx(m.implied_premium_pct, 1)}%</b> premium to landed COMEX (duty + local premium).
            {data?.contract.band_low != null && <> Today&apos;s MCX band {fmtInr(data.contract.band_low)} – {fmtInr(data.contract.band_high)} (±{data.contract.band_pct}%).</>}
          </div>
        </Panel>

        <Panel title="Your inputs" subtitle="saved for today" accent={T.violet} pad={10} bodyStyle={{ display: 'grid', gap: 10 }}>
          <Input label="MCX close override (₹ / 10 g)" value={saved.baseline} onChange={b => update({ baseline: b })}
            placeholder={data?.baseline.settlement_from_band ? `auto: ${fmtInr(data.baseline.settlement_from_band)}` : 'e.g. 149400'} />
          <Input label="MCX price now / pre-open (₹)" value={saved.mcx} onChange={x => update({ mcx: x })}
            placeholder={data?.mcx_price.source === 'ICICI Breeze' ? `live: ${fmtInr(mcxNow)}` : 'type the opening price'} />
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10 }}>
            <Input label="Chase limit (₹)" value={saved.threshold} onChange={x => update({ threshold: x })} />
            <Input label="EUR/USD trigger" value={saved.trigger} onChange={x => update({ trigger: x })} />
          </div>
          <div style={{ fontSize: 10, color: T.muted, lineHeight: 1.5 }}>
            Leave the close empty to use MCX&apos;s settlement for {data ? new Date(data.baseline.session).toLocaleDateString('en-IN', { day: '2-digit', month: 'short' }) : 'the last session'}.
            Connect ICICI on the Broker tab and the MCX price fills itself.
          </div>
        </Panel>
      </div>

      {/* 4. context */}
      <Panel title="Context" subtitle="moves since the MCX close · does not change fair value, tells you whether the move should hold" accent={T.cyan} pad={0}>
        <DataTable columns={ctxCols} rows={data?.context ?? []} rowKey={r => r.key} dense
          empty="Market context unavailable" />
      </Panel>

      {/* 5. headlines + manual checks */}
      <div style={{ display: 'grid', gap: 12, gridTemplateColumns: 'minmax(0, 1.5fr) minmax(300px, 1fr)' }}>
        <Panel title="Headlines" subtitle="last 24 h · gold, Fed, Iran/Hormuz, China, rupee, France" accent={T.amber} pad={0}>
          <div style={{ maxHeight: 360, overflowY: 'auto' }}>
            {(data?.headlines ?? []).length === 0 && <div style={{ padding: 14, color: T.muted, fontSize: 11 }}>No headlines in the last 24 hours.</div>}
            {(data?.headlines ?? []).map(h => (
              <a key={h.link} href={h.link} target="_blank" rel="noreferrer"
                style={{ display: 'grid', gridTemplateColumns: '92px 1fr 40px', gap: 10, padding: '7px 12px', textDecoration: 'none',
                         borderBottom: `1px solid ${T.border}`, alignItems: 'baseline' }}>
                <span style={{ fontSize: 9, letterSpacing: .8, color: T.cyan, textTransform: 'uppercase' }}>{h.topic}</span>
                <span style={{ fontSize: 12, color: T.text, lineHeight: 1.4 }}>{h.title}
                  <span style={{ color: T.dim, fontSize: 10 }}> · {h.publisher}</span></span>
                <span style={{ fontSize: 10, color: T.muted, textAlign: 'right' }}>{ago(h.published_at)}</span>
              </a>
            ))}
          </div>
        </Panel>

        <Panel title="Manual checks" subtitle={`${doneCount}/${data?.manual_checks.length ?? 0} done today · no free feed`} accent={T.violet} pad={0}>
          {(data?.manual_checks ?? []).map(c => {
            const done = !!saved.done[c.name]
            return (
              <div key={c.name} style={{ display: 'grid', gridTemplateColumns: '22px 1fr auto', gap: 8, alignItems: 'center',
                                         padding: '7px 12px', borderBottom: `1px solid ${T.border}`, opacity: done ? 0.55 : 1 }}>
                <input type="checkbox" checked={done} aria-label={`${c.name} checked`}
                  onChange={() => update({ done: { ...saved.done, [c.name]: !done } })} style={{ accentColor: T.green }} />
                <div>
                  <div style={{ fontSize: 11, color: done ? T.muted : T.text, textDecoration: done ? 'line-through' : 'none' }}>{c.name}</div>
                  <div style={{ fontSize: 10, color: T.dim }}>{c.what}</div>
                </div>
                <a href={c.url} target="_blank" rel="noreferrer" style={{ textDecoration: 'none' }}><Chip color={T.cyan} style={{ cursor: 'pointer' }}>↗ OPEN</Chip></a>
              </div>
            )
          })}
        </Panel>
      </div>

      <GoldAccuracyLog threshold={data?.threshold ?? 300} />

      {/* 6. method + data notes */}
      <div style={{ display: 'grid', gap: 6 }}>
        {(data?.notes ?? []).map(n => <Notice key={n} color={T.amber}>{n}</Notice>)}
        <div style={{ fontSize: 10, color: T.dim, lineHeight: 1.6 }}>
          <Label>Method</Label> Fair open = MCX settlement × COMEX ratio × USD/INR ratio, references averaged over the last 30 minutes
          before MCX closed ({data ? istTime(data.baseline.close_time) : '23:30'} IST). Settlement = midpoint of MCX&apos;s ±3% daily band
          from ICICI&apos;s public contract file. USD/INR before 09:00 is the offshore quote (a stand-in for the NDF). Rule: within the
          chase limit → trade your plan; beyond it → wait 15–30 min for the rupee&apos;s 09:00 open, then recompute. Research tool, not advice.
        </div>
      </div>
      </>}
    </Panel>
  )
}
