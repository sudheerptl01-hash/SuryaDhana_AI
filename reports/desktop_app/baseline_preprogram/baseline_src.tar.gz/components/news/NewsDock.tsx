'use client'

/**
 * NewsDock — the NEWS segment of the status line (footer), on every tab. Shows the latest
 * scan's date and pick count, and pulses amber when a scan file newer than the last one you
 * opened appears in new_scnner/. Click (or Shift+N) opens the News Catalyst Terminal.
 * Lives IN the footer row (no floating pill), so it never covers page content.
 */
import { useCallback, useEffect, useState } from 'react'
import { getNewsScans } from '@/lib/api'
import { NewsTerminal } from './NewsTerminal'
import type { ScanIndex } from './types'
import { T } from './format'

const SEEN_KEY = 'newsTerminal.seenVersion'

export function NewsDock() {
  const [open, setOpen] = useState(false)
  const [index, setIndex] = useState<ScanIndex | null>(null)
  const [seen, setSeen] = useState<number>(0)

  useEffect(() => {
    try { setSeen(Number(localStorage.getItem(SEEN_KEY) || 0)) } catch { /* storage unavailable */ }
  }, [])

  const poll = useCallback(async () => {
    try { setIndex((await getNewsScans()).data) } catch { /* backend restarting — retry next tick */ }
  }, [])

  useEffect(() => {
    poll()
    const id = setInterval(poll, 60_000)
    return () => clearInterval(id)
  }, [poll])

  const openTerminal = useCallback(() => {
    setOpen(true)
    const v = index?.latest_version ?? 0
    setSeen(v)
    try { localStorage.setItem(SEEN_KEY, String(v)) } catch { /* storage unavailable */ }
  }, [index])

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      const tag = (e.target as HTMLElement)?.tagName
      if (e.shiftKey && (e.key === 'N' || e.key === 'n') && tag !== 'INPUT' && tag !== 'TEXTAREA') {
        e.preventDefault(); openTerminal()
      }
    }
    window.addEventListener('keydown', onKey)
    window.addEventListener('suryadhana:open-news', openTerminal)      // fired by the command bar (NEWS <GO>)
    return () => {
      window.removeEventListener('keydown', onKey)
      window.removeEventListener('suryadhana:open-news', openTerminal)
    }
  }, [openTerminal])

  const latest = index?.scans[0]
  const isNew = !open && !!index?.latest_version && index.latest_version > seen
  const label = latest ? `${latest.date.replace(/(\d{4})(\d{2})(\d{2})/, '$3-$2')}` : '—'

  // one footer segment, three states: quiet · unread (amber pulse + count) · open (active)
  return (
    <>
      <button onClick={openTerminal}
        title={`News Catalyst Terminal (Shift+N) · latest scan ${label}${latest ? ` · ${latest.picks} picks` : ''}${isNew ? ' · NEW' : ''}`}
        style={{ display: 'inline-flex', alignItems: 'center', gap: 6, padding: '1px 7px', cursor: 'pointer',
                 background: open ? '#120e04' : 'none', font: 'inherit', letterSpacing: 'inherit',
                 border: `1px solid ${isNew || open ? `${T.amber}88` : 'transparent'}`, borderRadius: 2,
                 color: isNew ? T.text : T.muted }}>
        <style>{`@keyframes nd-pulse {0%,100%{opacity:1}50%{opacity:.35}}`}</style>
        <span style={{ width: 6, height: 6, borderRadius: 3, background: isNew ? T.amber : T.green,
                       animation: isNew ? 'nd-pulse 1.2s ease-in-out infinite' : undefined }} />
        <span style={{ color: T.amber, fontWeight: 700 }}>NEWS</span>
        <span>{label}</span>
        {latest && latest.picks >= 0 && (
          <span style={{ background: isNew ? T.amber : 'transparent', color: isNew ? T.bg : T.muted,
                         border: isNew ? 'none' : `1px solid ${T.border}`, fontWeight: 700, padding: '0 5px',
                         borderRadius: 2, lineHeight: '13px' }}>
            {latest.picks}
          </span>
        )}
        {isNew && <span style={{ color: T.amber, fontWeight: 700 }}>NEW</span>}
      </button>
      <NewsTerminal open={open} onClose={() => setOpen(false)} />
    </>
  )
}
